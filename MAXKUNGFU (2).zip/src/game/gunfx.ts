import { pcircle, pline, px, type Ctx } from './pixel';

/**
 * Pixel pistol FX after patch-gg/pixelfx (pistol-shots / muzzle-pistol / bullet-tracer / hit-spark).
 * Spiky white-cored muzzle, burning tracer, diamond-cross impact. All integer pixels.
 */
const F = ['#4a1712', '#8a1f17', '#c9281f', '#f2561d', '#ff8a2a', '#ffc23d', '#ffe26b', '#fff3a6', '#ffffff'];
const C = ['#4a1712', '#c9281f', '#f2561d', '#ff8a2a', '#ffe26b', '#fff3a6', '#ffffff'];

interface Flash { x: number; y: number; a: number; t: number; seed: number; big: boolean }
interface Hit {
  x: number; y: number; a: number; t: number;
  rays: { a: number; L: number; w: number }[];
}

function hash(n: number) { const s = Math.sin(n * 127.1) * 43758.5453; return s - Math.floor(s); }

export class GunFx {
  flashes: Flash[] = [];
  hits: Hit[] = [];

  bang(x: number, y: number, a: number, big = true) {
    this.flashes.push({ x, y, a, t: 0, seed: Math.random() * 999, big });
    if (this.flashes.length > 8) this.flashes.shift();
  }

  impact(x: number, y: number, a: number) {
    const s = Math.random() * 999;
    const tilt = (hash(s) - 0.5) * 0.16;
    this.hits.push({
      x, y, a, t: 0,
      rays: [
        { a: a + tilt, L: 18 + hash(s + 1) * 6, w: 2.2 },
        { a: a + Math.PI + tilt, L: 5 + hash(s + 2) * 3, w: 2 },
        { a: a - Math.PI / 2 + tilt, L: 9 + hash(s + 3) * 4, w: 2.4 },
        { a: a + Math.PI / 2 + tilt, L: 6 + hash(s + 4) * 3, w: 2.1 },
        { a: a - Math.PI / 4 + tilt, L: 4 + hash(s + 5) * 2, w: 1 },
      ],
    });
    if (this.hits.length > 12) this.hits.shift();
  }

  update(dt: number) {
    for (let i = this.flashes.length - 1; i >= 0; i--) { this.flashes[i].t += dt; if (this.flashes[i].t > 0.08) this.flashes.splice(i, 1); }
    for (let i = this.hits.length - 1; i >= 0; i--) { this.hits[i].t += dt; if (this.hits[i].t > 0.12) this.hits.splice(i, 1); }
  }

  draw(ctx: Ctx) {
    for (const f of this.flashes) this.drawFlash(ctx, f);
    for (const h of this.hits) this.drawHit(ctx, h);
  }

  private drawFlash(ctx: Ctx, f: Flash) {
    const t = f.t, frame = t < 0.033 ? 1 : 2;
    const s = (f.big ? 1.15 : 0.8) * (frame === 1 ? 1 : 0.72);
    const tilt = (hash(f.seed) - 0.5) * 0.1;
    const a = f.a + tilt;
    const pal = frame === 1 ? [F[8], F[7], F[6], F[3]] : [F[7], F[6], F[4], F[2]];
    const pop = Math.exp(-(t + 0.008) / 0.035);
    ctx.globalAlpha = 0.55 * pop;
    pcircle(ctx, f.x, f.y, (f.big ? 14 : 10) * pop, F[4]);
    ctx.globalAlpha = 0.35 * pop;
    pcircle(ctx, f.x, f.y, (f.big ? 6 : 4) * pop, F[8]);
    ctx.globalAlpha = 1;
    // spikes: forward, diags, cross, back stub (pixelfx flashShape)
    const lobes: { da: number; L: number; w: number }[] = [
      { da: 0, L: (frame === 1 ? 16 : 11) * s, w: 2 },
      { da: 0.45, L: (frame === 1 ? 9 : 6) * s, w: 1 },
      { da: -0.45, L: (frame === 1 ? 9 : 6) * s, w: 1 },
      { da: 1.05, L: (frame === 1 ? 6 : 4) * s, w: 1 },
      { da: -1.05, L: (frame === 1 ? 6 : 4) * s, w: 1 },
      { da: Math.PI, L: (frame === 1 ? 4.5 : 3) * s, w: 1 },
    ];
    for (const L of lobes) {
      const ang = a + L.da;
      const c = Math.cos(ang), sn = Math.sin(ang);
      for (let d = 0; d <= L.L; d += 0.8) {
        const u = d / L.L;
        const col = u < 0.22 ? pal[0] : u < 0.5 ? pal[1] : u < 0.78 ? pal[2] : pal[3];
        px(ctx, f.x + c * d, f.y + sn * d, col);
        if (u < 0.45 && L.w > 1) {
          px(ctx, f.x + c * d - sn, f.y + sn * d + c, pal[1]);
          px(ctx, f.x + c * d + sn, f.y + sn * d - c, pal[1]);
        }
      }
    }
    pcircle(ctx, f.x, f.y, frame === 1 ? 2.2 : 1.4, F[8]);
    px(ctx, f.x, f.y, '#ffffff');
  }

  private drawHit(ctx: Ctx, h: Hit) {
    const t = h.t;
    const pop = Math.exp(-t / 0.045);
    if (pop > 0.02) {
      ctx.globalAlpha = 0.3 * pop;
      pcircle(ctx, h.x, h.y, 11, C[3]);
      ctx.globalAlpha = 0.2 * pop;
      pcircle(ctx, h.x, h.y, 5, C[6]);
      ctx.globalAlpha = 1;
      pline(ctx, h.x, h.y, h.x + Math.cos(h.a) * 16 * pop, h.y + Math.sin(h.a) * 16 * pop, C[4], 1);
    }
    if (t < 0.025) {
      for (const r of h.rays) this.ray(ctx, h.x, h.y, r.a, r.L, r.w, 0);
      this.diamond(ctx, h.x, h.y, 3);
    } else if (t < 0.058) {
      for (const r of h.rays) this.ray(ctx, h.x, h.y, r.a, r.L * 1.15, r.w * 0.55, 0.12);
      this.diamond(ctx, h.x, h.y, 2);
    } else if (t < 0.092) {
      const r = h.rays[0];
      this.ray(ctx, h.x, h.y, r.a, r.L * 1.25, 0.7, 0.4);
    }
  }

  private ray(ctx: Ctx, x: number, y: number, a: number, L: number, w: number, from: number) {
    const c = Math.cos(a), s = Math.sin(a);
    for (let d = from * L; d <= L; d += 0.7) {
      const u = d / L;
      const col = u < 0.3 ? C[6] : u < 0.62 ? C[5] : u < 0.88 ? C[4] : C[3];
      px(ctx, x + c * d, y + s * d, col);
      if (w > 1.2 && u < 0.5) {
        px(ctx, x + c * d - s, y + s * d + c, u < 0.3 ? C[5] : C[4]);
        px(ctx, x + c * d + s, y + s * d - c, u < 0.3 ? C[5] : C[4]);
      }
    }
  }

  private diamond(ctx: Ctx, x: number, y: number, r: number) {
    for (let dy = -r - 1; dy <= r + 1; dy++) {
      for (let dx = -r - 1; dx <= r + 1; dx++) {
        const m = Math.abs(dx) + Math.abs(dy);
        if (m <= r) px(ctx, x + dx, y + dy, '#ffffff');
        else if (m === r + 1) px(ctx, x + dx, y + dy, C[3]);
      }
    }
  }
}
