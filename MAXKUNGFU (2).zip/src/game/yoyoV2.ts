import { pcircle, pline, px, type Ctx } from './pixel';
import type { Vec } from './types';
import type { Game } from './game';
import { MOVES } from './moves';

/**
 * YOYO V2 — trajectory freestyle (not physics-rope). Disc flies out and back on a
 * mathematical path, or orbits during breakdance. Combo strings live in moves.ts (YL..YAIR).
 */
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export class YoyoV2 {
  x = 0; y = 0;
  spin = 0;
  hitFlash = 0;
  trail: { x: number; y: number; t: number }[] = [];
  private clock = 0;
  private last: Vec = { x: 0, y: 0 };
  private init = false;
  hand: Vec = { x: 0, y: 0 };

  reset(x: number, y: number) {
    this.x = x; this.y = y; this.last = { x, y }; this.trail.length = 0; this.init = true; this.spin = 0;
  }

  update(g: Game, dt: number, hand: Vec) {
    if (dt <= 0) return;
    const p = g.player;
    if (!this.init) this.reset(hand.x, hand.y + 8);
    this.hand = hand;
    this.clock += dt;
    if (this.hitFlash > 0) this.hitFlash -= dt;

    const move = p.attackPhase !== 'none' && p.moveKey && MOVES[p.moveKey]?.yoyo ? MOVES[p.moveKey] : null;
    const attacking = !!move && p.attackPhase === 'active';
    const pt = g.attackPoseT();
    const origin: Vec = { x: p.x, y: p.y - 6 - p.z };
    const aim = p.attackPhase !== 'none' ? p.attackAim : p.aim;
    const fx = Math.cos(aim), fy = Math.sin(aim);
    const sx = -fy, sy = fx;

    let tx = hand.x + p.facing * 6, ty = hand.y + 8 + Math.sin(this.clock * 7) * 2;
    const reach = move ? Math.max(0, move.range * g.stats.meleeRange) : 70;
    if (move) {
      if (move.orbit && (p.attackPhase === 'active' || p.attackPhase === 'recover')) {
        const wide = move.id === 'y_storm' || move.id === 'y_bboyflare';
        const rad = (wide ? 54 : 46) * Math.min(1.35, 0.7 + g.stats.meleeRange * 0.3) + Math.sin(this.clock * 9) * 4;
        const w = wide ? 17 : 17;
        this.spin += w * dt;
        tx = origin.x + Math.cos(this.spin) * rad;
        ty = origin.y + Math.sin(this.spin) * rad * 0.7;
      } else {
        const u = pt < 0.3 ? 0 : pt < 0.6 ? (pt - 0.3) / 0.3 : 1 - (pt - 0.6) / 0.4 * 0.85;
        const ext = Math.sin(Math.PI * Math.max(0, Math.min(1, u)));
        const dist = 9 + Math.max(0, reach - 9) * ext;
        let side = 0;
        if (move.id === 'y_cross' || move.id === 'y_slide') side = Math.sin(2 * Math.PI * Math.max(0, Math.min(1, u))) * 18 * p.facing;
        if (move.id === 'y_windwhip' || move.id === 'y_windbreak') side = Math.sin(Math.PI * 2 * u) * 22;
        if (move.id === 'y_trapeze' || move.id === 'y_trapeze2' || move.id === 'y_onehand') side = Math.sin(Math.PI * u) * 12 * p.facing;
        tx = origin.x + fx * dist + sx * side;
        ty = origin.y + fy * dist + sy * side;
      }
    } else {
      this.spin += 12 * dt;
    }
    if (attacking && move?.orbit) this.spin += 0; // already advanced
    else if (attacking) this.spin += 12 * dt;

    const moved = Math.hypot(tx - this.x, ty - this.y);
    this.x = lerp(this.x, tx, Math.min(1, dt * 28));
    this.y = lerp(this.y, ty, Math.min(1, dt * 28));

    // trail
    for (const t of this.trail) t.t += dt;
    while (this.trail.length && this.trail[0].t > 0.23) this.trail.shift();
    if (move && moved > 0.3) {
      this.trail.push({ x: this.last.x, y: this.last.y, t: 0 });
      if (this.trail.length > 18) this.trail.shift();
    }
    this.last = { x: this.x, y: this.y };

    // start ring
    if (p.attackPhase === 'active' && p.attackElapsed < dt * 2 && move) {
      g.particles.ring(p.x, p.y - 6, 3, move.orbit ? 16 : 10, '#ffb84a', 0.2, 1);
      g.sfx.whoosh();
    }
    if (attacking && Math.random() < 0.16) {
      g.particles.add({ x: this.x + (Math.random() - 0.5) * 6, y: this.y + (Math.random() - 0.5) * 6, vx: 0, vy: -12, life: 0.18, c: Math.random() < 0.5 ? '#ffd166' : '#65ece2', k: 0, s: 1 });
    }
    if (attacking && (move!.id === 'y_windwhip' || move!.orbit || move!.id === 'y_airflare' || move!.id === 'y_onehand') && Math.random() < 0.12) {
      g.particles.smoke(p.x, p.y + 1, 1, '#9a9a9a', 18, 0.3);
    }
  }

  tip(): Vec { return { x: this.x, y: this.y }; }

  onHit() { this.hitFlash = 0.14; }

  draw(ctx: Ctx, g: Game) {
    if (!this.init) return;
    const p = g.player;
    const move = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
    const active = !!(move?.yoyo && p.attackPhase === 'active');

    // trail
    const tr = this.trail;
    for (let i = 1; i < tr.length; i++) {
      const a = tr[i - 1], b = tr[i];
      const k = Math.max(0, 1 - b.t / 0.23);
      if (k <= 0) continue;
      ctx.globalAlpha = k * 0.7;
      pline(ctx, a.x, a.y, b.x, b.y, i % 3 === 0 ? '#fff2b3' : '#ff6546', i === tr.length - 1 ? 2 : 1);
    }
    ctx.globalAlpha = 1;

    // string: hand -> sag mid -> disc
    const hx = this.hand.x, hy = this.hand.y;
    const sag = active ? 1.5 : 3;
    const mx = (hx + this.x) / 2, my = (hy + this.y) / 2 + sag;
    ctx.globalAlpha = 0.48;
    pline(ctx, hx, hy, mx, my, '#ffd9a2', 1);
    pline(ctx, mx, my, this.x, this.y, '#ffd9a2', 1);
    ctx.globalAlpha = 1;

    // glow ring
    const rr = active ? 6 : 4.5;
    ctx.globalAlpha = active ? 0.55 : 0.28;
    pcircle(ctx, this.x, this.y, rr, '#ffb84a');
    ctx.globalAlpha = 1;

    // disc layers
    pcircle(ctx, this.x, this.y, 3.6, '#29120f');
    pcircle(ctx, this.x, this.y, 2.8, this.hitFlash > 0 ? '#fff9d1' : '#f9563f');
    pcircle(ctx, this.x, this.y, 1.4, '#ffc35b');
    px(ctx, this.x - 1, this.y - 1, '#ffffff');

    if (active) {
      const a1 = this.spin, a2 = this.spin + 2.2;
      px(ctx, this.x + Math.cos(a1) * 4.2, this.y + Math.sin(a1) * 4.2, '#fff1af');
      px(ctx, this.x + Math.cos(a2) * 4.2, this.y + Math.sin(a2) * 4.2, '#67e5dc');
    }
  }
}
