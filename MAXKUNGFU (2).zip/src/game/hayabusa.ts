import { pcircle, pline, pring, px, type Ctx } from './pixel';
import { solvePose, type Skeleton } from './stick';
import type { Enemy, Pose, Vec } from './types';
import type { Move } from './moves';
import type { Game } from './game';

/**
 * HAYABUSA — Ninja Gaiden katana with Raiden (MGR) Blade Mode. No electricity.
 *
 *  Idle             ninja ready stance, blade drawn.
 *  LMB chain        MOON SLASH -> REVERSE FLOW -> AERIAL RAVE (360 hop) -> IZUNA DROP (grab, spin, slam).
 *                   Tap again after a cut lands to flow into the next.
 *  RMB tap          BLADE MODE: world slows. Three precise cuts paint white/crimson lines on the target.
 *                   The fourth beat is ZANDATSU — the lines burst into petals and the core is ripped.
 *  RMB hold+release FLYING SWALLOW: a ninja dash-cut. Body follows the blade, afterimages + petal trail.
 *
 *  Hits are the REAL blade segment (hand -> tip) swept through enemies. Trails are curved swooshes only.
 */
export const BLADE = 20;
const HIT_LEN = 29;

interface Cut {
  t: number; sw?: number; a0: number; a1: number; reach: number;
  dmg: number; lunge: number; kd?: boolean; launch?: number; big?: boolean;
}
interface StepDef {
  id: string; name: string; col: string; dur: number; cancelAt: number;
  cuts: Cut[]; pose: Pose; hop?: [number, number, number]; draw?: boolean;
}

export const STEPS: StepDef[] = [
  { id: 'moon', name: 'MOON SLASH', col: '#f2e6d8', dur: 0.36, cancelAt: 0.18, pose: 'h_slash', draw: true,
    cuts: [{ t: 0.07, sw: 0.045, a0: 1.15, a1: -0.95, reach: 52, dmg: 5.5, lunge: 64 }] },
  { id: 'reverse', name: 'REVERSE FLOW', col: '#ffb7c5', dur: 0.38, cancelAt: 0.2, pose: 'h_slash',
    cuts: [{ t: 0.08, sw: 0.05, a0: -1.15, a1: 1.05, reach: 52, dmg: 5.5, lunge: 50 }] },
  { id: 'rave', name: 'AERIAL RAVE', col: '#ffffff', dur: 0.62, cancelAt: 0.46, pose: 'h_spin', hop: [0.02, 0.5, 8],
    cuts: [
      { t: 0.16, sw: 0.12, a0: -0.4, a1: -3.6, reach: 44, dmg: 4.5, lunge: 28 },
      { t: 0.34, sw: 0.12, a0: -3.6, a1: -6.8, reach: 44, dmg: 4.5, lunge: 22, kd: true },
    ] },
  { id: 'izuna', name: 'IZUNA DROP', col: '#ff6a8a', dur: 0.92, cancelAt: 99, pose: 'h_izuna', hop: [0.04, 0.72, 14],
    cuts: [{ t: 0.58, sw: 0.14, a0: -2.6, a1: 0.4, reach: 48, dmg: 16, lunge: 40, kd: true, launch: 30, big: true }] },
];

const SWALLOW: StepDef = { id: 'swallow', name: 'FLYING SWALLOW', col: '#f2e6d8', dur: 0.42, cancelAt: 0.3, pose: 'h_slash', hop: [0.0, 0.36, 5],
  cuts: [{ t: 0.18, sw: 0.22, a0: 0.4, a1: -0.8, reach: 90, dmg: 8, lunge: 0, kd: true }] };

const keyCache = new Map<StepDef, { t: number; a: number }[]>();
function keysOf(def: StepDef) {
  let k = keyCache.get(def);
  if (k) return k;
  const arr: { t: number; a: number }[] = [{ t: 0, a: def.cuts[0].a0 }];
  def.cuts.forEach((c, i) => {
    const pre = c.t - (c.sw ?? 0.035);
    if (pre > arr[arr.length - 1].t) arr.push({ t: pre, a: c.a0 });
    arr.push({ t: c.t, a: c.a1 });
    if (!def.cuts[i + 1]) arr.push({ t: c.t + 0.22, a: c.a1 });
  });
  keyCache.set(def, arr);
  return arr;
}
function bladeRel(def: StepDef, t: number): number {
  const k = keysOf(def);
  if (t <= k[0].t) return k[0].a;
  for (let i = 1; i < k.length; i++) {
    if (t <= k[i].t) {
      const u = (t - k[i - 1].t) / Math.max(1e-4, k[i].t - k[i - 1].t);
      const e = 1 - (1 - u) * (1 - u) * (1 - u * 0.35);
      return k[i - 1].a + (k[i].a - k[i - 1].a) * e;
    }
  }
  return k[k.length - 1].a;
}

const mk = (o: Partial<Move> & { id: string; name: string; dmg: number }): Move => ({
  pose: 'idle', structure: o.dmg * 4.2, range: 40, arc: 2, windup: 0, active: 0, recover: 0, kb: 180, knockdown: false, lunge: 0,
  hitstop: 0.045, shake: 0.24, sfx: 'slash', limb: 'blade', hitR: 4, bleed: true, ...o,
});
const angDiff = (a: number, b: number) => { let d = a - b; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; };
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
function segDist(ax: number, ay: number, bx: number, by: number, cx: number, cy: number) {
  const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy;
  const t = l > 0 ? cl(((cx - ax) * dx + (cy - ay) * dy) / l) : 0;
  return Math.hypot(ax + dx * t - cx, ay + dy * t - cy);
}

interface Slice { e: Enemy; a: number }
interface TrailPt { x: number; y: number; a: number; t: number }
interface Step { def: StepDef; t: number; tPrev: number; started: boolean[]; landed: boolean[]; hit: Set<number>[]; aim: number; facing: number }
type Mode = 'idle' | 'step' | 'blade' | 'zandatsu';

export class Hayabusa {
  mode: Mode = 'idle';
  step: Step | null = null;
  chainIdx = 0;
  queued = false;
  rHeld = false;
  charge = 0;
  slices: Slice[] = [];
  bladeCuts = 0;
  private bladeT = 0;
  private zanT = 0;
  private lastAim = 0;
  sinceAct = 9;
  bodyPose: Pose | null = null;
  bodyT = 0;
  lockAim: number | null = null;
  moveMul = 1;
  bladeA = 0;
  bladeFrac = 0;
  ext = 0;
  hop = 0;
  trail: TrailPt[] = [];
  trailCol = '#f2e6d8';
  private t = 0;
  private swallowFrom: Vec | null = null;

  reset() {
    this.mode = 'idle'; this.step = null; this.chainIdx = 0; this.queued = false; this.rHeld = false; this.charge = 0;
    this.slices.length = 0; this.trail.length = 0; this.bodyPose = null; this.lockAim = null; this.sinceAct = 9; this.hop = 0;
  }
  nextStep(): StepDef { return STEPS[this.chainIdx % STEPS.length]; }

  update(g: Game, dt: number) {
    if (dt <= 0) return;
    const p = g.player, m = g.input.mouse;
    this.t += dt; this.sinceAct += dt;
    this.bodyPose = null; this.lockAim = null; this.moveMul = 1; this.ext = 0; this.hop = 0;
    while (this.trail.length && this.t - this.trail[0].t > 0.26) this.trail.shift();
    for (let i = this.slices.length - 1; i >= 0; i--) if (this.slices[i].e.dead) this.slices.splice(i, 1);

    const interrupted = p.stunT > 0 || p.holdT > 0 || p.dashT > 0 || !!p.focusDash || p.rageDash || g.state !== 'playing' || !!p.fatality;
    if (interrupted && this.mode !== 'idle') { this.mode = 'idle'; this.step = null; this.queued = false; this.rHeld = false; this.slices.length = 0; this.trail.length = 0; }

    const rdown = m.rdown && !interrupted;
    if (!interrupted && !p.airborne) {
      if (m.pressed) {
        if (this.mode === 'blade') this.bladeCut(g);
        else if (this.mode === 'idle') this.startStep(g, STEPS[this.chainIdx % STEPS.length]);
        else if (this.mode === 'step') this.queued = true;
      }
      if (m.rpressed) {
        const ok = this.mode === 'idle' || (this.mode === 'step' && this.step !== null && this.step.t >= Math.min(this.step.def.cancelAt, this.step.def.dur * 0.8));
        if (ok) { this.mode = 'idle'; this.step = null; this.charge = 0; this.rHeld = true; }
      }
    }
    if (this.rHeld) {
      this.charge += dt;
      if (!rdown) {
        this.rHeld = false;
        const held = this.charge; this.charge = 0;
        if (held < 0.18) this.startBlade(g);
        else this.startStep(g, SWALLOW);
      }
    }

    switch (this.mode) {
      case 'idle': {
        if (!p.moving && !this.rHeld) { this.bodyPose = 'h_idle'; this.bodyT = 0; }
        if (this.rHeld) { this.bodyPose = 'h_blade'; this.bodyT = cl(this.charge / 0.4); this.lockAim = this.aimAt(g).ang; this.moveMul = 0.45; }
        if (this.chainIdx > 0 && this.sinceAct > 0.85) this.chainIdx = 0;
        break;
      }
      case 'step': {
        const S = this.step!, def = S.def;
        S.tPrev = S.t; S.t += dt;
        this.lockAim = S.aim; this.moveMul = def.id === 'swallow' ? 0 : 0.12; this.sinceAct = 0;
        this.updateBlade(S);
        if (def.id === 'swallow' && this.swallowFrom) {
          const u = cl(S.t / 0.28);
          const e = 1 - (1 - u) * (1 - u);
          const dx = Math.cos(S.aim), dy = Math.sin(S.aim);
          const dist = 92;
          const nx = this.swallowFrom.x + dx * dist * e, ny = this.swallowFrom.y + dy * dist * e;
          if (g.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; }
          p.vx = p.vy = 0; p.kx = p.ky = 0;
          if (Math.round(S.t * 40) % 2 === 0) g.addAfterimage({ x: p.x, y: p.y, facing: S.facing, aim: S.aim, scale: 1 }, '#f2e6d8', { x: dx, y: dy });
          if (Math.random() < 0.7) this.petal(g, p.x, p.y - 8, 1);
        }
        if (def.id === 'izuna' && S.t < 0.5) {
          // lock onto nearest enemy and ride them down
          let best: Enemy | null = null, bd = 70;
          for (const e of g.enemies) { if (e.dead || e.spawnT > 0) continue; const d = Math.hypot(e.x - p.x, e.y - p.y); if (d < bd) { bd = d; best = e; } }
          if (best) { p.x = lerp(p.x, best.x, 0.18); p.y = lerp(p.y, best.y, 0.18); }
        }
        const sk = solvePose(g.playerStickOpts(def.pose, S.t / def.dur));
        const hand: Vec = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
        for (let i = 0; i < def.cuts.length; i++) {
          const c = def.cuts[i], start = c.t - (c.sw ?? 0.035);
          if (!S.started[i] && S.t >= start) { S.started[i] = true; this.cutStart(g, S, c); }
          if (S.t >= start && S.tPrev <= c.t + 0.03) this.sweep(g, S, c, i, hand);
          if (c.big && !S.landed[i] && S.t >= c.t) { S.landed[i] = true; this.impact(g, S, c); }
        }
        if (S.t >= def.cancelAt && this.queued && this.chainIdx < STEPS.length && !def.id.startsWith('swallow')) { this.queued = false; this.startStep(g, STEPS[this.chainIdx % STEPS.length]); break; }
        if (S.t >= def.dur) { this.mode = 'idle'; this.step = null; this.queued = false; if (def.id === 'izuna' || def.id === 'swallow') this.chainIdx = 0; }
        break;
      }
      case 'blade': {
        this.bladeT += dt;
        const a = this.aimAt(g).ang;
        this.lockAim = a; this.lastAim = a; this.moveMul = 0.2; this.sinceAct = 0;
        this.bodyPose = 'h_blade'; this.bodyT = 0.6; this.bladeFrac = 1; this.ext = 0.5;
        this.bladeA = a - 0.4 * (Math.cos(a) >= 0 ? 1 : -1);
        if (this.bladeCuts >= 3 || this.bladeT > 2.1) this.startZandatsu(g);
        break;
      }
      case 'zandatsu': {
        this.zanT += dt;
        this.lockAim = this.lastAim; this.moveMul = 0; this.sinceAct = 0;
        this.bodyPose = 'h_slash'; this.bodyT = cl(this.zanT / 0.28);
        const f = Math.cos(this.lastAim) >= 0 ? 1 : -1;
        this.bladeA = this.lastAim + (-1.6 + 3.2 * cl(this.zanT / 0.1)) * f;
        this.bladeFrac = 1; this.ext = 1;
        if (this.zanT >= 0.55) { this.mode = 'idle'; this.chainIdx = 0; this.slices.length = 0; }
        break;
      }
    }
  }

  private updateBlade(S: Step) {
    const f = S.facing, def = S.def;
    this.bladeA = S.aim + bladeRel(def, S.t) * f;
    this.bladeFrac = def.draw ? cl(S.t / 0.045) : 1;
    let e = 0.4;
    for (const c of def.cuts) e = Math.max(e, 0.4 + 0.6 * cl(1 - Math.abs(S.t - c.t) / 0.16));
    this.ext = e;
    if (def.hop) { const [t0, t1, peak] = def.hop; this.hop = peak * Math.sin(Math.PI * cl((S.t - t0) / (t1 - t0))); }
    this.trailCol = def.col;
    this.bodyPose = def.pose; this.bodyT = S.t / def.dur;
  }

  private aimAt(g: Game): { ang: number; dist: number } {
    const p = g.player, mw = g.mouseWorld();
    let ang = Math.atan2(mw.y - (p.y - 6), mw.x - p.x), dist = 999;
    let best: Enemy | null = null, bs = Infinity;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d > 130) continue;
      const da = Math.abs(angDiff(Math.atan2(e.y - 6 - (p.y - 6), e.x - p.x), ang));
      if (da > 0.95) continue;
      const sc = da * 70 + d * 0.35;
      if (sc < bs) { bs = sc; best = e; }
    }
    if (best) { ang = Math.atan2(best.y - 6 - (p.y - 6), best.x - p.x); dist = Math.hypot(best.x - p.x, best.y - p.y); }
    return { ang, dist };
  }

  private startStep(g: Game, def: StepDef) {
    const p = g.player;
    const a = this.aimAt(g).ang;
    const f = Math.cos(a) >= 0 ? 1 : -1;
    this.step = { def, t: 0, tPrev: 0, started: def.cuts.map(() => false), landed: def.cuts.map(() => false), hit: def.cuts.map(() => new Set<number>()), aim: a, facing: f };
    const idx = STEPS.indexOf(def);
    this.chainIdx = idx >= 0 ? idx + 1 : 0;
    this.mode = 'step'; this.queued = false; this.sinceAct = 0; this.lastAim = a;
    this.bladeFrac = def.draw ? 0 : 1;
    this.trail.length = 0;
    this.swallowFrom = def.id === 'swallow' ? { x: p.x, y: p.y } : null;
    p.facing = f;
    g.sfx.whoosh();
    g.texts.add(p.x, p.y - 28, def.name, def.col, 1, 0.65);
    if (def.id === 'swallow') { g.sfx.dash(); p.iframes = Math.max(p.iframes, 0.35); }
    if (def.id === 'izuna') g.sfx.focus();
  }

  private startBlade(g: Game) {
    const p = g.player;
    this.mode = 'blade'; this.bladeT = 0; this.bladeCuts = 0; this.slices.length = 0; this.step = null;
    this.lastAim = this.aimAt(g).ang;
    g.slow(1.8, 0.28);
    g.sfx.focus();
    g.particles.ring(p.x, p.y - 6, 18, 6, '#f2e6d8', 0.28, 1);
    g.texts.add(p.x, p.y - 28, 'BLADE MODE', '#ffffff', 1, 0.7);
    this.petal(g, p.x, p.y - 8, 8);
  }

  /** one precision cut in blade mode — paints a line on whoever the blade actually touches */
  private bladeCut(g: Game) {
    if (this.bladeCuts >= 3) return;
    const p = g.player;
    const a = this.aimAt(g).ang;
    const f = Math.cos(a) >= 0 ? 1 : -1;
    this.bladeCuts++;
    this.lastAim = a; this.lockAim = a;
    // a short snap of the blade
    const a0 = a + (this.bladeCuts % 2 ? 1.3 : -1.3) * f, a1 = a + (this.bladeCuts % 2 ? -0.9 : 0.9) * f;
    this.bladeA = a1; this.ext = 1; this.bladeFrac = 1;
    const sk = solvePose(g.playerStickOpts('h_slash', 0.5));
    const hx = p.x + sk.fhand.x, hy = p.y + sk.fhand.y - p.z;
    const tx = hx + Math.cos(a1) * HIT_LEN, ty = hy + Math.sin(a1) * HIT_LEN * 0.6;
    const mv = mk({ id: 'h_blade', name: 'BLADE MODE', dmg: 3.2, kb: 80, hitstop: 0.04, shake: 0.15 });
    g.sfx.slash(1.1);
    g.katana.addArc(hx, hy + 4, 16, a0, a1, this.bladeCuts === 3 ? '#ff6a8a' : '#f2e6d8', 0, 0.18);
    this.petal(g, hx + Math.cos(a1) * 12, hy + Math.sin(a1) * 8, 3);
    p.kx += Math.cos(a) * 40; p.ky += Math.sin(a) * 36;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      if (segDist(hx, hy, tx, ty, e.x, e.y - e.z - 5) > e.r + 4) continue;
      g.meleeHitEnemy(e, mv, Math.atan2(e.y - p.y, e.x - p.x), { x: e.x, y: e.y - e.z - 5 });
      this.slices.push({ e, a: a1 + (Math.random() - 0.5) * 0.2 });
    }
  }

  private startZandatsu(g: Game) {
    const p = g.player;
    this.mode = 'zandatsu'; this.zanT = 0;
    const targets = new Set<Enemy>();
    for (const sl of this.slices) if (!sl.e.dead) targets.add(sl.e);
    g.sfx.slash(0.7); g.sfx.sheathe();
    this.petal(g, p.x, p.y - 8, 18);
    if (!targets.size) { g.texts.add(p.x, p.y - 26, 'MISS', '#9a9a9a', 1, 0.4); return; }
    g.flash('#f2e6d8', 0.22); g.slow(0.4, 0.18); g.shake(0.55);
    g.say('ZANDATSU', '#ffb7c5', 2, 1.0);
    p.focus = Math.min(300, p.focus + 40 * g.stats.focusGain);
    g.addOfa(10 + targets.size * 4);
    g.heal(1);
    const k = g.stats.meleeDmg;
    for (const e of targets) {
      const ang = Math.atan2(e.y - p.y, e.x - p.x);
      const ex = e.x, ey = e.y - e.z - 5;
      g.particles.burst(ex, ey, 14, '#ffb7c5', 140, 0.5);
      g.particles.lines(ex, ey, 5, '#ffffff', ang, 220);
      g.blood.spray(ex, ey, ang, 5, true);
      g.damageEnemy(e, 8 * k, 40, ang, 280, { knockdown: true, hitstop: 0.05, shake: 0.4, melee: true, launch: 50 });
      this.petal(g, ex, ey, 8);
    }
  }

  private cutStart(g: Game, S: Step, c: Cut) {
    const p = g.player;
    let nearest = Infinity;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d > c.reach + e.r) continue;
      if (Math.abs(angDiff(Math.atan2(e.y - p.y, e.x - p.x), S.aim)) > 1.3) continue;
      nearest = Math.min(nearest, d);
    }
    const lg = nearest < Infinity ? Math.min(c.lunge, Math.max(5, nearest - 14)) : c.lunge * 0.55;
    p.kx += Math.cos(S.aim) * lg * 8; p.ky += Math.sin(S.aim) * lg * 8 * 0.9;
    g.sfx.slash(c.big ? 0.65 : 1.0);
    g.addAfterimage({ x: p.x, y: p.y, facing: S.facing, aim: S.aim, scale: 1 }, S.def.col, { x: Math.cos(S.aim), y: Math.sin(S.aim) });
    this.petal(g, p.x + Math.cos(S.aim) * 10, p.y - 6, c.big ? 6 : 2);
  }

  private sweep(g: Game, S: Step, c: Cut, ci: number, hand: Vec) {
    const f = S.facing;
    const start = c.t - (c.sw ?? 0.035);
    const t0 = Math.max(S.tPrev, start), t1 = Math.min(S.t, c.t + 0.03);
    if (t1 < t0) return;
    const n = Math.max(1, Math.ceil((t1 - t0) / 0.006));
    const mv = mk({
      id: 'h_cut', name: S.def.name, dmg: c.dmg, kb: c.big ? 340 : 180, knockdown: !!c.kd, launch: c.launch,
      hitstop: c.big ? 0.1 : 0.05, shake: c.big ? 0.55 : 0.25, finisher: !!c.big,
    });
    for (let s = 0; s <= n; s++) {
      const tt = lerp(t0, t1, s / n);
      const a = S.aim + bladeRel(S.def, tt) * f;
      const tx = hand.x + Math.cos(a) * HIT_LEN, ty = hand.y + Math.sin(a) * HIT_LEN * 0.6;
      for (const e of g.enemies) {
        if (e.dead || e.spawnT > 0 || S.hit[ci].has(e.id)) continue;
        if (segDist(hand.x, hand.y, tx, ty, e.x, e.y - e.z - 5) > e.r + 3) continue;
        S.hit[ci].add(e.id);
        g.meleeHitEnemy(e, mv, Math.atan2(e.y - g.player.y, e.x - g.player.x), { x: e.x, y: e.y - e.z - 5 });
      }
    }
  }

  private impact(g: Game, S: Step, c: Cut) {
    const p = g.player;
    const ix = p.x + Math.cos(S.aim) * 18, iy = p.y + Math.sin(S.aim) * 10;
    g.katana.addArc(p.x, p.y, 18, S.aim + c.a0 * S.facing, S.aim + c.a1 * S.facing, S.def.col, 0, 0.24);
    g.particles.shockwave(ix, iy - 2, 26, '#ffb7c5', 0.28);
    g.shake(0.45); g.hitstop = Math.max(g.hitstop, 0.05);
    g.sfx.slam();
    this.petal(g, ix, iy, 12);
    if (S.def.id === 'izuna') { g.flash('#ffb7c5', 0.16); g.shockwaveHit(ix, iy, 28, 5 * g.stats.meleeDmg, -1); g.say('IZUNA', '#ff6a8a', 2, 0.8); }
  }

  private petal(g: Game, x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, sp = 20 + Math.random() * 50;
      g.particles.add({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.7 - 18, life: 0.45 + Math.random() * 0.25, c: Math.random() < 0.55 ? '#ffb7c5' : '#f2e6d8', k: 0, s: 1 });
    }
  }

  draw(ctx: Ctx, g: Game, sk: Skeleton) {
    const p = g.player;
    const f = this.lockAim !== null ? (Math.cos(this.lockAim) >= 0 ? 1 : -1) : p.facing;
    const W = (v: Vec): Vec => ({ x: p.x + v.x, y: p.y + v.y - p.z });
    const hip = W(sk.hip), fh = W(sk.fhand), bh = W(sk.bhand);
    const pose = this.bodyPose;

    if ((pose === 'h_slash' || pose === 'h_spin' || pose === 'h_izuna' || pose === 'h_blade') && this.bladeFrac > 0.35) {
      const last = this.trail[this.trail.length - 1];
      if (!last || last.a !== this.bladeA || last.t !== this.t) this.trail.push({ x: fh.x, y: fh.y, a: this.bladeA, t: this.t });
    }

    // blade-mode ring (thin, outside the body — not a costume)
    if (this.mode === 'blade' || (this.rHeld && this.charge > 0.05 && this.mode === 'idle')) {
      const k = 0.45 + Math.sin(this.t * 10) * 0.15;
      ctx.globalAlpha = k;
      pring(ctx, hip.x, hip.y - 3, 16 + Math.sin(this.t * 6) * 1.5, '#f2e6d8', 1);
      ctx.globalAlpha = 1;
    }

    // curved swoosh (fan of the blade, never a straight chord)
    const tr = this.trail;
    for (let i = 1; i < tr.length; i++) {
      const A = tr[i - 1], B = tr[i];
      const age = this.t - B.t;
      if (age > 0.18) continue;
      const da = B.a - A.a;
      if (Math.abs(da) < 0.02 || Math.abs(da) > 7) continue;
      const fade = 1 - age / 0.18;
      const steps = Math.max(1, Math.ceil(Math.abs(da) / 0.09));
      for (let s = 0; s <= steps; s++) {
        const u = s / steps, ang = A.a + da * u, hx = lerp(A.x, B.x, u), hy = lerp(A.y, B.y, u);
        const c = Math.cos(ang), sn = Math.sin(ang) * 0.6;
        ctx.globalAlpha = fade * 0.45;
        pline(ctx, hx + c * BLADE * 0.5, hy + sn * BLADE * 0.5, hx + c * BLADE * 1.02, hy + sn * BLADE * 1.02, this.trailCol, 1);
        ctx.globalAlpha = fade * 0.95;
        px(ctx, hx + c * BLADE * 1.05, hy + sn * BLADE * 1.05, '#ffffff');
      }
    }
    ctx.globalAlpha = 1;

    // the sword
    if (pose === 'h_slash' || pose === 'h_spin' || pose === 'h_izuna' || pose === 'h_blade' || (pose === 'h_idle' && this.bladeFrac > 0)) {
      const a = pose === 'h_idle' ? (p.aim + Math.PI * 0.85) : this.bladeA;
      const fr = pose === 'h_idle' ? 1 : this.bladeFrac;
      const len = BLADE * Math.max(fr, pose === 'h_idle' ? 1 : 0);
      if (len > 1.4) {
        const tip = { x: fh.x + Math.cos(a) * len, y: fh.y + Math.sin(a) * len * 0.6 };
        this.blade(ctx, fh, tip, g);
      }
      const bx = fh.x - Math.cos(a) * 4, by = fh.y - Math.sin(a) * 2.4;
      pline(ctx, fh.x, fh.y, bx, by, '#000', 3);
      pline(ctx, fh.x, fh.y, bx, by, '#4a1020', 1); // crimson wrap, not gold — ninja
      pcircle(ctx, bx, by, 1, '#f2e6d8');
    } else if (pose === 'h_idle') {
      const a = p.aim + Math.PI * 0.9;
      const tip = { x: fh.x + Math.cos(a) * BLADE, y: fh.y + Math.sin(a) * BLADE * 0.6 };
      this.blade(ctx, fh, tip, g);
    } else {
      // sheathed at the hip while running
      pline(ctx, bh.x, bh.y, bh.x - f * 13, bh.y - 3, '#000', 3);
      pline(ctx, bh.x, bh.y, bh.x - f * 13, bh.y - 3, '#2a1020', 1);
    }

    // blade-mode cut lines on targets (white / crimson, never cyan/electric)
    for (const sl of this.slices) {
      if (sl.e.dead) continue;
      const ex = sl.e.x, ey = sl.e.y - sl.e.z - 5;
      const dx = Math.cos(sl.a) * 12, dy = Math.sin(sl.a) * 12 * 0.65;
      ctx.globalAlpha = 0.6 + Math.sin(this.t * 22 + sl.a) * 0.25;
      pline(ctx, ex - dx, ey - dy, ex + dx, ey + dy, '#ff6a8a', 2);
      ctx.globalAlpha = 1;
      pline(ctx, ex - dx, ey - dy, ex + dx, ey + dy, '#ffffff', 1);
    }
  }

  private blade(ctx: Ctx, base: Vec, tip: Vec, g: Game) {
    const dx = tip.x - base.x, dy = tip.y - base.y, l = Math.hypot(dx, dy) || 1;
    const nx = -dy / l, ny = dx / l;
    pline(ctx, base.x, base.y, tip.x, tip.y, '#000', 3);
    pline(ctx, base.x - nx * 0.5, base.y - ny * 0.5, tip.x - nx * 0.3, tip.y - ny * 0.3, '#6a7380', 1);
    pline(ctx, base.x, base.y, tip.x, tip.y, '#f4f1ea', 1);
    pline(ctx, base.x + nx * 0.7, base.y + ny * 0.7, tip.x + nx * 0.2, tip.y + ny * 0.2, '#ffffff', 1);
    // crimson hamon (blood-tempered), not electric cyan
    ctx.globalAlpha = 0.7;
    pline(ctx, base.x + dx * 0.25, base.y + dy * 0.25, base.x + dx * 0.7, base.y + dy * 0.7, '#c4202c', 1);
    ctx.globalAlpha = 1;
    pcircle(ctx, tip.x, tip.y, 0.6, '#ffffff');
    pline(ctx, base.x + nx * 1.8, base.y + ny * 1.8, base.x - nx * 1.8, base.y - ny * 1.8, '#4a1020', 2);
    const gt = (g.time * 2.6) % 1;
    px(ctx, base.x + dx * gt, base.y + dy * gt, '#ffffff');
  }
}
