import { useEffect, useRef, useState, type ReactNode } from 'react';
import { VIEW_H, VIEW_W, ZONES } from './game/constants';
import { Game, type UIState } from './game/game';
import { MOVE_LIST } from './game/moves';
import { MUTATIONS } from './game/mutations';
import { MutIcon, MutIconSm } from './MutIcon';

const initialUI: UIState = {
  state: 'menu', level: 1, zoneName: ZONES[0].name, zoneSub: ZONES[0].sub, score: 0, age: 20, deathCounter: 1, deaths: 0, kills: 0,
  bestCombo: 0, choices: [], save: null, best: { level: 0, score: 0 }, muted: false, mutations: [], ageGain: 0, hp: 5, maxHp: 5, accent: '#ff5a36',
  mode: 'story', wave: 0, survivalTime: 0, bestWave: 0, bestSurvivalScore: 0, blood: 'combined', v2: true, long: false,
};

function useScale() {
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const calc = () => {
      const s = Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H);
      setScale(s > 0 ? s : 1);
    };
    calc();
    window.addEventListener('resize', calc);
    return () => window.removeEventListener('resize', calc);
  }, []);
  return scale;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [ui, setUi] = useState<UIState>(initialUI);
  const scale = useScale();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let g: Game;
    try {
      g = new Game(canvas);
    } catch (err) {
      console.error('[KUNGFU DRIFTER] failed to create game', err);
      return;
    }
    gameRef.current = g;
    (window as unknown as { __kf?: Game }).__kf = g;
    g.onUI = (u) => setUi(u);
    try {
      g.start();
    } catch (err) {
      console.error('[KUNGFU DRIFTER] failed to start game', err);
    }
    g.input.focus();

    // Virtual / keyboard strike support: when no real cursor is over the game, aim the strike at the
    // nearest living enemy. Otherwise a punch sent from the showcase's on-screen button would fly
    // toward whatever stale spot the aim was last left at (the sim aims purely from the cursor).
    const aimAssist = (game: Game) => {
      if (performance.now() - game.input.mouseMovedAt < 1500) return;
      const p = game.player;
      let bi = -1; let bd = Infinity;
      for (let i = 0; i < game.enemies.length; i++) {
        const e = game.enemies[i];
        if (e.dead || e.spawnT > 0) continue;
        const d = (e.x - p.x) * (e.x - p.x) + (e.y - p.y) * (e.y - p.y);
        if (d < bd) { bd = d; bi = i; }
      }
      if (bi < 0) return;
      const t = game.enemies[bi];
      game.input.mouse.x = (t.x - game.cam.x - VIEW_W / 2) * game.zoom + VIEW_W / 2;
      game.input.mouse.y = (t.y - game.cam.y - VIEW_H / 2) * game.zoom + VIEW_H / 2;
    };

    const onMsg = (ev: MessageEvent) => {
      if (!ev.data || typeof ev.data !== 'object') return;
      if (ev.data.type === 'KF_KEYDOWN') {
        window.dispatchEvent(new KeyboardEvent('keydown', { code: ev.data.code, key: ev.data.key || '', bubbles: true }));
      } else if (ev.data.type === 'KF_KEYUP') {
        window.dispatchEvent(new KeyboardEvent('keyup', { code: ev.data.code, key: ev.data.key || '', bubbles: true }));
      } else if (ev.data.type === 'KF_MOUSEDOWN') {
        const game = gameRef.current;
        if (!game) return;
        aimAssist(game);
        game.input.synthMouseDown(typeof ev.data.button === 'number' ? ev.data.button : 0);
      } else if (ev.data.type === 'KF_MOUSEUP') {
        gameRef.current?.input.synthMouseUp(typeof ev.data.button === 'number' ? ev.data.button : 0);
      } else if (ev.data.type === 'KF_ACTION') {
        if (ev.data.action === 'start') {
          if (gameRef.current?.state === 'menu') gameRef.current.newGame(null);
          else if (gameRef.current?.state === 'paused') gameRef.current.resume();
          else if (gameRef.current?.state === 'dead') gameRef.current.newGame(null);
        } else if (ev.data.action === 'pause') {
          if (gameRef.current?.state === 'playing') gameRef.current.pause();
          else if (gameRef.current?.state === 'paused') gameRef.current.resume();
        }
      }
    };
    window.addEventListener('message', onMsg);

    return () => {
      window.removeEventListener('message', onMsg);
      g.destroy();
      if (gameRef.current === g) gameRef.current = null;
    };
  }, []);

  const g = () => gameRef.current!;
  // Keyboard focus must be inside the game (it usually runs in an iframe). Every click / menu button grabs it.
  const focusGame = () => gameRef.current?.input.focus();
  const act = (fn: () => void) => () => { focusGame(); fn(); focusGame(); };
  const w = VIEW_W * scale, h = VIEW_H * scale;
  const fontPx = Math.min(22, Math.max(12, Math.round(4.5 * scale)));
  // V2 renders into a display-sized backing store so the picture is resampled exactly ONCE (hard pixel edges).
  // V1 keeps the classic fixed 480x270 buffer that CSS stretches — that is the old, softer look.
  const dpr = typeof window === 'undefined' ? 1 : Math.min(2, window.devicePixelRatio || 1);
  const bw = ui.v2 ? Math.max(VIEW_W, Math.min(1920, Math.round(w * dpr))) : VIEW_W;
  const bh = ui.v2 ? Math.max(VIEW_H, Math.round((bw * VIEW_H) / VIEW_W)) : VIEW_H;

  return (
    <div
      className="relative w-screen h-screen bg-black flex items-center justify-center overflow-hidden select-none"
      onContextMenu={(e) => e.preventDefault()}
      onMouseDown={focusGame}
      onPointerDown={focusGame}
      onClick={focusGame}
    >
      {ui.state !== 'menu' && <button
        onClick={act(() => g().toggleV2())}
        onPointerDown={(e) => e.stopPropagation()}
        className="pixel absolute top-2 right-2 z-30 cursor-pointer border-2 px-2 py-1 leading-none transition-colors hover:brightness-150"
        style={{
          borderColor: ui.v2 ? '#7df9ff' : '#6a6a6a',
          color: ui.v2 ? '#7df9ff' : '#9a9a9a',
          background: 'rgba(0,0,0,0.78)',
          fontSize: Math.max(9, Math.round(fontPx * 0.62)),
        }}
        title={ui.v2 ? 'V2 aktif: pixel tajam + ragdoll/pusing ala STICK FIST. Klik untuk kembali ke V1 (tampilan lama).' : 'V1 aktif: build lama. Klik untuk menyalakan V2 (pixel tajam + ragdoll baru).'}
      >
        {ui.v2 ? '* V2 NEW' : 'V1 OLD'}
      </button>}
      {ui.state !== 'menu' && <button
        onClick={act(() => g().toggleLong())}
        onPointerDown={(e) => e.stopPropagation()}
        className="pixel absolute top-2 right-24 z-30 cursor-pointer border-2 px-2 py-1 leading-none transition-colors hover:brightness-150"
        style={{
          borderColor: ui.long ? '#ffd27f' : '#6a6a6a',
          color: ui.long ? '#ffd27f' : '#9a9a9a',
          background: 'rgba(0,0,0,0.78)',
          fontSize: Math.max(9, Math.round(fontPx * 0.62)),
        }}
        title={ui.long ? 'LONG LIMBS aktif: badan/tangan/kaki 2.5x panjang normal. Klik untuk kembali normal.' : 'Klik untuk mode LONG LIMBS: badan/tangan/kaki 2.5x panjang normal (atau tekan L).'}
      >
        {ui.long ? '* LONG x2.5' : 'LONG x2.5'}
      </button>}
      <div className="relative" style={{ width: w, height: h, fontSize: fontPx }}>
        <canvas
          ref={canvasRef}
          width={bw}
          height={bh}
          tabIndex={0}
          className="block w-full h-full cursor-none outline-none"
          style={{ imageRendering: 'pixelated' }}
        />
        {/* scanlines */}
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.13]"
          style={{ backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.6) 0px, rgba(0,0,0,0.6) 1px, transparent 2px, transparent 4px)' }}
        />
        {ui.state === 'menu' && (
          <div className="absolute inset-0 cursor-default overflow-hidden">
            <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.25) 42%, rgba(0,0,0,0.82) 100%)' }} />
            <div className="absolute inset-0 pointer-events-none" style={{ background: `radial-gradient(70% 55% at 50% 38%, ${ui.accent}40 0%, transparent 72%)` }} />
            <div className="relative h-full w-full flex flex-col items-center justify-center px-[1.5em]">
              <div className="pixel text-[0.55em] tracking-[0.55em] text-white/55 mb-[1.1em]">KUNG FU ROGUELITE</div>
              <div className="relative flex flex-col items-center">
                <div
                  className="pixel text-[3.6em] leading-[0.9] tracking-wider select-none"
                  style={{ color: ui.accent, textShadow: `0.08em 0.08em 0 #000, 0 0 0.45em ${ui.accent}, 0 0 1.4em ${ui.accent}88` }}
                >
                  KUNGFU
                </div>
                <div
                  className="pixel text-[3.6em] leading-[0.9] tracking-wider select-none"
                  style={{ color: '#fff', textShadow: '0.08em 0.08em 0 #000, 0 0 0.5em rgba(255,255,255,0.35)' }}
                >
                  DRIFTER
                </div>
              </div>
              <button
                onClick={act(() => g().newSurvival())}
                onPointerDown={(e) => e.stopPropagation()}
                className="play-btn pixel mt-[2.2em] text-[1.35em] text-black cursor-pointer border-0 leading-none"
                style={{
                  background: ui.accent,
                  padding: '0.72em 2.4em 0.62em',
                  boxShadow: '0.22em 0.22em 0 #000, 0 0 1.4em ' + ui.accent + '66',
                  minWidth: '8.5em',
                }}
              >
                PLAY
              </button>
              <div className="pixel text-[0.5em] text-white/40 mt-[1.1em] tracking-[0.25em]">TAP · ENTER</div>
            </div>
          </div>
        )}
        {ui.state === 'mutation' && (
          <Overlay dim="bg-black/80">
            <div className="flex flex-col items-center gap-[1.2em] w-full px-[1em]">
              <div className="pixel text-[1.6em] leading-none" style={{ color: ui.accent, textShadow: `0.08em 0.08em 0 #000, 0 0 0.6em ${ui.accent}` }}>{ui.mode === 'survival' ? `WAVE ${ui.wave} SURVIVED` : `LEVEL ${ui.level} CLEARED`}</div>
              <div className="pixel text-[0.85em] text-white tracking-[0.2em]">CHOOSE A MUTATION</div>
              <div className="flex gap-[1.2em] w-full max-w-[64em] justify-center flex-wrap">
                {ui.choices.map((m, i) => (
                  <button
                    key={m.id}
                    onClick={act(() => g().chooseMutation(i))}
                    className="group relative flex flex-col items-center gap-[0.7em] w-[19em] min-h-[22em] p-[1.3em] pt-[1.6em] border-[0.28em] bg-black/80 hover:bg-black cursor-pointer overflow-hidden"
                    style={{ borderColor: m.color, boxShadow: `0.4em 0.4em 0 #000, 0 0 1.6em ${m.color}44, inset 0 0 2em ${m.color}18` }}
                  >
                    <div className="absolute top-0 left-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="absolute top-0 right-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="absolute bottom-0 left-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="absolute bottom-0 right-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="relative flex items-center justify-center w-[7em] h-[7em] border-[0.18em]" style={{ borderColor: m.color, background: '#050505', boxShadow: `inset 0 0 1.2em ${m.color}33` }}>
                      <MutIcon id={m.id} color={m.color} />
                    </div>
                    <div className="pixel text-[0.95em] text-center leading-tight" style={{ color: m.color, textShadow: '0.06em 0.06em 0 #000' }}>{m.name}</div>
                    <div className="pixel text-[0.62em] text-white/80 leading-relaxed text-center max-w-[16em]">{m.desc}</div>
                    <div className="pixel text-[0.7em] mt-auto px-[0.7em] py-[0.25em] text-black" style={{ background: m.color }}>{i + 1}</div>
                  </button>
                ))}
              </div>
              <div className="pixel text-[0.6em] text-white/50">{ui.mode === 'survival' ? `NEXT: WAVE ${ui.wave + 1}${(ui.wave + 1) % 5 === 0 ? ' - BOSS WAVE' : ''}` : `NEXT: LEVEL ${ui.level + 1} - ${ZONES[Math.min(19, Math.floor(ui.level / 10))].name}`}</div>
            </div>
          </Overlay>
        )}
        {ui.state === 'dead' && (
          <Overlay dim="bg-transparent">
            <div className="flex flex-col items-center gap-[0.8em] text-center animate-[fadeIn_1s_ease-in]">
              <div className="pixel text-[2.4em] text-red-500" style={{ textShadow: '0.08em 0.08em 0 #000' }}>YOU DIED</div>
              {ui.mode === 'survival' ? (
                <div className="pixel text-[0.7em] text-yellow-300">YOU SURVIVED {ui.wave} WAVES - {Math.floor(ui.survivalTime / 60)}:{String(Math.floor(ui.survivalTime % 60)).padStart(2, '0')}</div>
              ) : (
                <>
                  <div className="pixel text-[0.8em] text-yellow-300">
                    AGE {ui.age} <span className="text-white/60">→</span> {ui.age + ui.ageGain}
                  </div>
                  <div className="pixel text-[0.55em] text-white/60">YOU GROW OLDER. YOU HIT HARDER. YOU HAVE LESS HEALTH.</div>
                  {ui.age + ui.ageGain >= 70 ? (
                    <div className="pixel text-[0.6em] text-red-400">THIS BODY CANNOT GO ON...</div>
                  ) : (
                    <div className="pixel text-[0.6em] text-white/50">DEATH COUNTER: {ui.deathCounter} (RESETS ON BOSS KILL)</div>
                  )}
                </>
              )}
              <Btn accent={ui.accent} onClick={act(() => g().respawn())} primary>{ui.mode === 'survival' ? 'RESULTS [ENTER]' : 'RISE AGAIN [ENTER]'}</Btn>
            </div>
          </Overlay>
        )}
        {ui.state === 'gameover' && (
          <Overlay dim="bg-black/80">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[2em] text-red-500">{ui.mode === 'survival' ? 'OVERRUN' : 'DIED OF OLD AGE'}</div>
              <div className="pixel text-[0.6em] text-white/60">{ui.mode === 'survival' ? `YOU HELD OUT FOR ${ui.wave} WAVES (${Math.floor(ui.survivalTime / 60)}:${String(Math.floor(ui.survivalTime % 60)).padStart(2, '0')})${ui.wave >= ui.bestWave && ui.wave > 0 ? ' - NEW RECORD!' : ''}` : `THE ROAD ENDED AT LEVEL ${ui.level} - ${ui.zoneName}`}</div>
              <Stats ui={ui} />
              <div className="flex gap-[0.8em] mt-[0.5em]">
                <Btn accent={ui.accent} onClick={act(() => g().restartZone())} primary>{ui.mode === 'survival' ? 'SURVIVE AGAIN' : 'RETRY ZONE'}</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>MENU</Btn>
              </div>
            </div>
          </Overlay>
        )}
        {ui.state === 'victory' && (
          <Overlay dim="bg-black/75">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[2em] text-yellow-300" style={{ textShadow: '0 0 1em #ffd700' }}>YOU ARE THE MASTER</div>
              <div className="pixel text-[0.6em] text-white/70">200 FLOORS. ONE FIST. AGE {ui.age}.</div>
              <Stats ui={ui} />
              <Btn accent={ui.accent} onClick={act(() => g().toMenu())} primary>RETURN TO MENU</Btn>
            </div>
          </Overlay>
        )}
        {ui.state === 'paused' && (
          <Overlay dim="bg-black/70">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[1.6em] text-white">PAUSED</div>
              <div className="pixel text-[0.55em] text-white/60">{ui.mode === 'survival' ? `SURVIVAL - WAVE ${ui.wave}` : `LEVEL ${ui.level} - ${ui.zoneName} - AGE ${ui.age}`}</div>
              <div className="flex flex-wrap justify-center gap-[0.4em] max-w-[30em]">
                {ui.mutations.map((id, i) => {
                  const m = MUTATIONS.find((mm) => mm.id === id);
                  return m ? <span key={i} title={m.name}><MutIconSm id={m.id} color={m.color} /></span> : null;
                })}
              </div>
              <div className="flex gap-[0.8em]">
                <Btn accent={ui.accent} onClick={act(() => g().resume())} primary>RESUME [ESC]</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toggleMute())}>{ui.muted ? 'UNMUTE' : 'MUTE'} [M]</Btn>
                <Btn accent="#ff4d4d" onClick={act(() => g().cycleBlood())}>BLOOD: {ui.blood.toUpperCase()} [B]</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>QUIT</Btn>
              </div>
              <Controls compact />
            </div>
          </Overlay>
        )}
      </div>
    </div>
  );
}

function Overlay({ children, dim = 'bg-black/40' }: { children: ReactNode; dim?: string }) {
  return (
    <div className={`absolute inset-0 flex items-center justify-center overflow-y-auto ${dim} cursor-default`}>
      <div className="max-h-full py-[1em] flex items-center justify-center w-full">{children}</div>
    </div>
  );
}

function Btn({ children, onClick, primary, accent }: { children: ReactNode; onClick: () => void; primary?: boolean; accent: string }) {
  return (
    <button
      onClick={onClick}
      className={`pixel text-[0.7em] px-[1.2em] py-[0.7em] border-[0.15em] transition-all cursor-pointer hover:translate-x-[0.1em] hover:-translate-y-[0.1em] active:translate-y-0 ${primary ? 'text-black' : 'text-white bg-black/60 hover:bg-white/10'}`}
      style={primary ? { background: accent, borderColor: accent, boxShadow: '0.25em 0.25em 0 #000' } : { borderColor: accent, boxShadow: '0.25em 0.25em 0 #000' }}
    >
      {children}
    </button>
  );
}

function Stats({ ui }: { ui: UIState }) {
  return (
    <div className="grid grid-cols-2 gap-x-[2em] gap-y-[0.3em] pixel text-[0.6em] text-white/80 bg-black/50 p-[1em] border border-white/20">
      <span className="text-white/50">SCORE</span><span>{ui.score}</span>
      <span className="text-white/50">KILLS</span><span>{ui.kills}</span>
      <span className="text-white/50">BEST COMBO</span><span>{ui.bestCombo}</span>
      <span className="text-white/50">DEATHS</span><span>{ui.deaths}</span>
      <span className="text-white/50">MUTATIONS</span><span>{ui.mutations.length}</span>
      {ui.mode === 'survival' ? <><span className="text-white/50">WAVES</span><span>{ui.wave}</span></> : <><span className="text-white/50">BEST LEVEL</span><span>{ui.best.level}</span></>}
    </div>
  );
}

function Controls({ compact }: { compact?: boolean }) {
  return (
    <div className={`grid ${compact ? 'grid-cols-2 gap-x-[2em]' : 'grid-cols-1 sm:grid-cols-2 gap-x-[2em]'} gap-y-[0.25em] pixel text-[0.5em] text-left bg-black/60 border border-white/15 p-[1em] max-w-[52em]`}>
      <div className="text-white/40 col-span-full mb-[0.3em]">CONTROLS</div>
      <Row k="WASD" v="MOVE (HOLD TO RUN)" /><Row k="MOUSE" v="AIM" />
      <Row k="LMB" v="LIGHT ATTACK / SHOOT" /><Row k="RMB" v="HEAVY (PALM STRIKE)" />
      <Row k="RUN + LMB (FISTS)" v="TAEKWONDO FLYING SIDE KICK" /><Row k="RUN + RMB (FISTS)" v="MK FLYING KICK / RUNNING STRAIGHT" />
      <Row k="RUN + LMB (WEAPON)" v="DRAGON LASH / IAIJUTSU / GRAND SLAM / PHANTOM CROSS" />
      <Row k="SPACE (AIR) + LMB" v="DIVE KICK" />
      <Row k="SPACE" v="JUMP (HOP OVER BULLETS)" /><Row k="SHIFT" v="SHADOW STEP (DASH, I-FRAMES)" />
      <Row k="C" v="PARRY" />
      <Row k="E" v="FOCUS STRIKE" /><Row k="F" v="FATALITY (ANY ENEMY IN REACH)" />
      <Row k="X" v="ONE FOR ALL (AT 25+ CHARGE): WORLD SLOWS TO 30%, YOU RUN AT REAL TIME, STRIKES AUTO-LOCK" />
      <Row k="CLICK TEMPO (FISTS)" v="FAST = WING CHUN  /  MEDIUM = BLACK LEG KICKS  /  SLOW = KUNG FU HEAVIES" /><Row k="R" v="RAGE (WHEN METER FULL): LMB = DASH + EXECUTE" />
            <Row k="Q / 1-9-0 / WHEEL" v="FIST / PISTOL / RIFLE / NUNCHAKU / KATANA / AXE / DUAL / YOYO / TAKAMURA / HAYABUSA" />
      <Row k="HAYABUSA (0) LMB" v="NINJA CHAIN: MOON SLASH > REVERSE FLOW > AERIAL RAVE > IZUNA DROP (TAP TO FLOW · THE BLADE ITSELF HITS)" />
      <Row k="HAYABUSA (0) RMB" v="TAP = BLADE MODE (SLOW-MO, 3 PRECISE CUTS, THEN ZANDATSU — PETALS, NO LIGHTNING) · HOLD = FLYING SWALLOW DASH-CUT" />
      <Row k="AXE (6) RMB" v="IDLE/WALK = THROW (FLIES, HITS, RETURNS TO YOUR HAND) · RMB AGAIN = RECALL EARLY" />
      <Row k="AXE (6) SHIFT+RMB" v="LEAP SMASH: JUMP THEN CHOP STRAIGHT DOWN (SHOCKWAVE + FROST). IF THE AXE IS OUT IT RACES BACK SO YOU SLAM WITH IT" />
      <Row k="TAKAMURA (9) LMB" v="SWORD CHAIN: BATTOUJUTSU > KESA X-CUT > CHAMPLOO SPIN > RYU TSUI SEN (TAP AGAIN AFTER A CUT TO FLOW INTO THE NEXT · THE BLADE ITSELF DOES THE HITTING)" />
      <Row k="TAKAMURA (9) RMB" v="TAP = RYU SHO SEN (RISING CUT, LAUNCHES) · HOLD + RELEASE = AMAKAKERU RYU NO HIRAMEKI (TWO HUGE CUTS, STRONGER THE LONGER YOU HOLD)" />
      <Row k="TAKAMURA (9) NOTO" v="EVERY ENEMY YOU CUT IS MARKED · WHEN THE BLADE CLICKS BACK INTO THE SAYA THE DELAYED CUTS LAND" />
      <Row k="B" v="BLOOD: NORMAL / GORE / COMBINED" /><Row k="ESC" v="PAUSE" />
      <Row k="V" v="SWITCH LOOK: V2 = CRISP PIXELS + GAME1 RAGDOLL (WALL BOUNCE, DIZZY STARS, KICKABLE BODIES) / V1 = CLASSIC BUILD" />
      {!compact && (
        <>
          <div className="text-white/40 col-span-full mt-[0.8em] mb-[0.3em]">KUNG FU TECHNIQUES</div>
          {MOVE_LIST.map((m) => (
            <div key={m.name} className="col-span-full flex gap-[1em] leading-relaxed">
              <span className="text-yellow-300 min-w-[9em]">{m.keys}</span>
              <span className="text-white">{m.name}</span>
              <span className="text-white/50">{m.desc}</span>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-[1em]">
      <span className="text-yellow-300 min-w-[9em]">{k}</span>
      <span className="text-white/80">{v}</span>
    </div>
  );
}
