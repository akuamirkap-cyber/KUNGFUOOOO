import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./game2/App";

createRoot(document.getElementById("root")!).render(<App />);
