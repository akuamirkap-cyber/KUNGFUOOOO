// YO-YO V2 — B-BOY FREESTYLE (follows "PANDUAN LENGKAP SENJATA YO-YO FREESTYLE").
// Moves have windup / active / recover; the disc path is computed from aim, reach and a side wave,
// orbit moves circle the origin; a 18-point trail (0.23 s life) follows the disc.
import { pcircle, pline, prect, type Ctx } from './pixel';
import type { Pose } from './types';

export interface Y2Move {
  key: string; name: string; dmg: number; range: number; hitR: number; windup: number; active: number; recover: number;
  kb: number; knockdown?: boolean; launch?: number; rehit?: number; orbit?: 0 | 46 | 54; wave?: number; pose: Pose;
  power?: boolean; /** breakdance legs also sweep (windmill/spin/freeze/air) */ legs?: boolean; holdH?: boolean; finisher?: boolean;
}

export const Y2: Record<string, Y2Move> = {
  YL:     { key: 'YL', name: 'TOPROCK THROW', dmg: 5, range: 78, hitR: 6, windup: 0.04, active: 0.34, recover: 0.10, kb: 160, wave: 8, pose: 'jab' },
  YLL:    { key: 'YLL', name: 'CROSS STEP LOOP', dmg: 6, range: 82, hitR: 7, windup: 0.04, active: 0.38, recover: 0.10, kb: 180, wave: -18, pose: 'cross' },
  YLLL:   { key: 'YLLL', name: 'WINDMILL WHIP', dmg: 10, range: 90, hitR: 8, windup: 0.06, active: 0.48, recover: 0.16, kb: 320, knockdown: true, launch: 120, wave: 14, pose: 'sweep', power: true, legs: true },
  YLLLL:  { key: 'YLLLL', name: 'ONE HAND FREEZE', dmg: 8, range: 86, hitR: 8, windup: 0.05, active: 0.40, recover: 0.12, kb: 260, wave: -10, pose: 'cranekick', power: true, legs: true },
  YLLLLL: { key: 'YLLLLL', name: 'B-BOY FLARE', dmg: 5, range: 64, hitR: 8, windup: 0.06, active: 0.56, recover: 0.16, kb: 260, rehit: 0.24, orbit: 54, pose: 'spinback', power: true, legs: true, finisher: true },
  YH:     { key: 'YH', name: 'BREAKDANCE ORBIT', dmg: 3.5, range: 54, hitR: 7, windup: 0.06, active: 0.65, recover: 0.13, kb: 200, rehit: 0.28, orbit: 46, pose: 'spin', power: true, legs: true, holdH: true },
  YHH:    { key: 'YHH', name: 'FLARE STORM', dmg: 4, range: 64, hitR: 8, windup: 0.06, active: 0.70, recover: 0.16, kb: 240, rehit: 0.24, orbit: 54, pose: 'dragontail', power: true, legs: true, holdH: true, finisher: true },
  YLH:    { key: 'YLH', name: 'FREEZE TRAPEZE', dmg: 8, range: 85, hitR: 8, windup: 0.05, active: 0.44, recover: 0.14, kb: 280, knockdown: true, launch: 150, wave: 20, pose: 'cranekick', power: true, legs: true },
  YLLH:   { key: 'YLLH', name: 'FREEZE TRAPEZE', dmg: 9, range: 88, hitR: 8, windup: 0.05, active: 0.44, recover: 0.14, kb: 320, knockdown: true, launch: 180, wave: -20, pose: 'cranekick', power: true, legs: true },
  YHL:    { key: 'YHL', name: 'WINDMILL BREAK', dmg: 8, range: 92, hitR: 8, windup: 0.04, active: 0.44, recover: 0.12, kb: 300, knockdown: true, wave: 16, pose: 'sweep', power: true, legs: true },
  YRUN:   { key: 'YRUN', name: 'SLIDE THROW', dmg: 9, range: 96, hitR: 8, windup: 0.04, active: 0.39, recover: 0.12, kb: 340, knockdown: true, wave: 0, pose: 'runpunch' },
  YAIR:   { key: 'YAIR', name: 'AIR FLARE', dmg: 8, range: 85, hitR: 8, windup: 0.04, active: 0.38, recover: 0.12, kb: 280, wave: 12, pose: 'spin', power: true, legs: true },
};

type Phase = 'none' | 'windup' | 'active' | 'recover';

export class Yoyo2 {
  move: Y2Move | null = null;
  phase: Phase = 'none';
  t = 0; // time inside the current phase
  combo = 'Y'; comboTimer = 0; buffered: 'L' | 'H' | null = null;
  aim = 0; spin = 0; flashT = 0;
  origin = { x: 0, y: 0 }; hand = { x: 0, y: 0 };
  pos = { x: 0, y: 0 }; prev = { x: 0, y: 0 };
  trail: { x: number; y: number; t: number }[] = [];
  hits: Record<number, number> = {};
  hitOnce: Set<number> = new Set();
  bob = 0;

  get active() { return this.phase !== 'none'; }
  get u() { return this.move && this.phase === 'active' ? Math.min(1, this.t / this.move.active) : this.phase === 'recover' ? 1 : 0; }
  /** 0..1 progress over the whole move (drives the body pose) */
  get poseT() {
    const m = this.move; if (!m) return 0;
    const tot = m.windup + m.active + m.recover;
    const el = this.phase === 'windup' ? this.t : this.phase === 'active' ? m.windup + this.t : m.windup + m.active + this.t;
    return Math.min(1, el / tot);
  }

  start(key: string, aim: number) {
    const m = Y2[key]; if (!m) return;
    this.move = m; this.phase = 'windup'; this.t = 0; this.aim = aim; this.hits = {}; this.hitOnce.clear(); this.buffered = null;
    this.combo = key === 'YLLLLL' || key === 'YRUN' || key === 'YAIR' ? 'Y' : key;
  }

  /** advance; `holdH` sustains the active phase of orbit moves. returns 'active-start' on the first active frame */
  step(dt: number, holdH: boolean): 'active-start' | 'done' | null {
    this.comboTimer -= dt; this.flashT = Math.max(0, this.flashT - dt);
    const m = this.move;
    if (!m) { if (this.comboTimer <= 0) this.combo = 'Y'; return null; }
    this.t += dt;
    let ev: 'active-start' | 'done' | null = null;
    if (this.phase === 'windup' && this.t >= m.windup) { this.phase = 'active'; this.t -= m.windup; ev = 'active-start'; }
    if (this.phase === 'active') {
      if (m.holdH && holdH && this.t > m.active * 0.85) this.t = m.active * 0.5; // hold K / RMB keeps spinning
      if (this.t >= m.active) { this.phase = 'recover'; this.t -= m.active; }
    }
    if (this.phase === 'recover' && this.t >= m.recover) { this.phase = 'none'; this.move = null; this.comboTimer = 0.9; ev = 'done'; }
    return ev;
  }

  update(dt: number, ox: number, oy: number, hand: { x: number; y: number }, reachMul: number, time: number) {
    this.origin = { x: ox, y: oy }; this.hand = hand; this.prev = { ...this.pos };
    const m = this.move;
    this.spin += dt * (m?.orbit ? 17 : 12);
    if (m && this.phase === 'active') {
      if (m.orbit) {
        const r = Math.min(m.orbit * reachMul, m.orbit * 1.6) + Math.sin(time * 9) * 4;
        this.pos = { x: ox + Math.cos(this.spin) * r, y: oy + Math.sin(this.spin) * r * 0.62 };
      } else {
        const u = this.u, reach = m.range * reachMul, ext = Math.sin(Math.PI * u);
        const d = 9 + Math.max(0, reach - 9) * ext;
        const fx = Math.cos(this.aim), fy = Math.sin(this.aim), sx = -fy, sy = fx;
        const side = Math.sin(2 * Math.PI * u) * (m.wave ?? 0);
        this.pos = { x: ox + fx * d + sx * side, y: oy + (fy * d + sy * side) * 0.62 };
      }
    } else {
      // resting near the hand with a small bob (windup / recover ease toward it)
      this.bob += dt * 5;
      const tgt = { x: hand.x, y: hand.y + 5 + Math.sin(this.bob) * 1.2 };
      const k = this.phase === 'none' ? 1 : 1 - Math.pow(0.0001, dt);
      this.pos = { x: this.pos.x + (tgt.x - this.pos.x) * k, y: this.pos.y + (tgt.y - this.pos.y) * k };
    }
    // trail: store the previous position when the disc moved > 0.3 units during a move; 0.23 s life, max 18
    for (let i = this.trail.length - 1; i >= 0; i--) { this.trail[i].t += dt; if (this.trail[i].t > 0.23) this.trail.splice(i, 1); }
    if (m && Math.hypot(this.pos.x - this.prev.x, this.pos.y - this.prev.y) > 0.3) {
      this.trail.unshift({ x: this.prev.x, y: this.prev.y, t: 0 });
      if (this.trail.length > 18) this.trail.pop();
    }
  }

  draw(ctx: Ctx, hand: { x: number; y: number }, time: number) {
    const act = this.phase === 'active';
    // trail: #ff6546 with periodic #fff2b3 accents; newest segment 2px; alpha fades with age (max 0.7)
    let prevPt = { x: this.pos.x, y: this.pos.y };
    for (let i = 0; i < this.trail.length; i++) {
      const p = this.trail[i];
      ctx.globalAlpha = 0.7 * (1 - p.t / 0.23);
      pline(ctx, prevPt.x, prevPt.y, p.x, p.y, i % 4 === 2 ? '#fff2b3' : '#ff6546', i === 0 ? 2 : 1);
      prevPt = p;
    }
    // string: hand -> sagging midpoint -> disc, #ffd9a2 at ~48%
    const sag = act ? 1.5 : 3;
    const mx = (hand.x + this.pos.x) / 2, my = (hand.y + this.pos.y) / 2 + sag;
    ctx.globalAlpha = 0.48;
    pline(ctx, hand.x, hand.y, mx, my, '#ffd9a2', 1); pline(ctx, mx, my, this.pos.x, this.pos.y, '#ffd9a2', 1);
    // glow ring #ffb84a: r 4.5 idle / 6 active, alpha .28 / .55
    ctx.globalAlpha = act ? 0.55 : 0.28;
    const rr = act ? 6 : 4.5;
    for (let a = 0; a < Math.PI * 2; a += 0.35) prect(ctx, Math.round(this.pos.x + Math.cos(a) * rr), Math.round(this.pos.y + Math.sin(a) * rr), 1, 1, '#ffb84a');
    ctx.globalAlpha = 1;
    // layered disc: dark base #29120f r3.6, body #f9563f r2.8 (hit flash #fff9d1), gold core #ffc35b r1.4, white glint
    pcircle(ctx, this.pos.x, this.pos.y, 3.6, '#29120f');
    pcircle(ctx, this.pos.x, this.pos.y, 2.8, this.flashT > 0 ? '#fff9d1' : '#f9563f');
    pcircle(ctx, this.pos.x, this.pos.y, 1.4, '#ffc35b');
    prect(ctx, Math.round(this.pos.x - 2), Math.round(this.pos.y - 2), 1, 1, '#ffffff');
    if (act) {
      const a = time * 30;
      prect(ctx, Math.round(this.pos.x + Math.cos(a) * 5), Math.round(this.pos.y + Math.sin(a) * 5), 1, 1, '#fff1af');
      prect(ctx, Math.round(this.pos.x - Math.cos(a) * 5), Math.round(this.pos.y - Math.sin(a) * 5), 1, 1, '#67e5dc');
    }
  }
}
