// YOYO — freestyle string weapon. Each trick is a parametric path of the yoyo relative to the hand.
import { pcircle, pline, prect, type Ctx } from './pixel';

export interface YoyoTrick { id: string; name: string; dur: number; dmg: number; kb: number; structure: number; reach: number; launch?: number; rehit: number; finisher?: boolean }

export const YOYO_TRICKS: Record<string, YoyoTrick> = {
  throw:   { id: 'throw', name: 'FORWARD PASS', dur: 0.32, dmg: 5, kb: 220, structure: 25, reach: 46, rehit: 0.3 },
  dog:     { id: 'dog', name: 'WALK THE DOG', dur: 0.5, dmg: 4, kb: 120, structure: 30, reach: 44, rehit: 0.12 },
  world:   { id: 'world', name: 'AROUND THE WORLD', dur: 0.55, dmg: 4, kb: 260, structure: 25, reach: 30, rehit: 0.18 },
  zigzag:  { id: 'zigzag', name: 'ZIG ZAG', dur: 0.5, dmg: 4, kb: 150, structure: 25, reach: 42, rehit: 0.1 },
  cradle:  { id: 'cradle', name: 'ROCK THE CRADLE', dur: 0.5, dmg: 5, kb: 200, structure: 30, reach: 26, rehit: 0.15 },
  uppercut:{ id: 'uppercut', name: 'SKY ROCKET', dur: 0.36, dmg: 5, kb: 60, structure: 35, reach: 40, launch: 230, rehit: 0.3 },
  split:   { id: 'split', name: 'SPLIT THE ATOM', dur: 0.5, dmg: 4, kb: 240, structure: 25, reach: 36, rehit: 0.14 },
  atomic:  { id: 'atomic', name: 'ATOMIC BOMB', dur: 0.85, dmg: 9, kb: 520, structure: 70, reach: 56, rehit: 0.12, finisher: true },
  orbit:   { id: 'orbit', name: 'ORBIT STORM', dur: 0.9, dmg: 4, kb: 300, structure: 25, reach: 34, rehit: 0.14, finisher: true },
  lasso:   { id: 'lasso', name: 'LASSO DASH', dur: 0.4, dmg: 7, kb: 360, structure: 45, reach: 52, rehit: 0.3 },
};
export const YOYO_FREESTYLE = ['throw', 'dog', 'world', 'zigzag', 'cradle', 'uppercut', 'split'];

export class Yoyo {
  trick: YoyoTrick | null = null;
  t = 0; aim = 0; facing = 1;
  hand = { x: 0, y: 0 };
  pos = { x: 0, y: 0 };
  prev = { x: 0, y: 0 };
  spin = 0;
  trail: { x: number; y: number }[] = [];
  hold = false; // RMB held keeps orbit alive
  hits: Record<number, number> = {};

  get active() { return !!this.trick; }
  start(id: string, aim: number, facing: number) {
    this.trick = YOYO_TRICKS[id]; this.t = 0; this.aim = aim; this.facing = facing; this.hits = {};
  }
  get u() { return this.trick ? Math.min(1, this.t / this.trick.dur) : 0; }

  /** yoyo offset from the hand for the current trick (screen space, y squashed for the 3/4 view) */
  offset(): { x: number; y: number } {
    const tr = this.trick, u = this.u, a = this.aim, f = this.facing;
    const fx = Math.cos(a), fy = Math.sin(a) * 0.6, sx = -fy, sy = fx;
    const out = (d: number, s = 0, up = 0) => ({ x: fx * d + sx * s, y: fy * d + sy * s - up });
    const there = Math.sin(u * Math.PI); // 0 -> 1 -> 0
    if (!tr) return { x: 0, y: 6 };
    switch (tr.id) {
      case 'throw': return out(tr.reach * Math.pow(there, 0.7));
      case 'lasso': return out(tr.reach * Math.pow(there, 0.6));
      case 'dog': { const d = tr.reach * Math.min(1, u * 2.2) * (u > 0.75 ? (1 - u) / 0.25 : 1); return { x: fx * d, y: fy * d + 8 }; }
      case 'world': { const ang = -Math.PI / 2 + u * Math.PI * 2 * f; return { x: Math.cos(ang) * tr.reach, y: Math.sin(ang) * tr.reach * 0.75 }; }
      case 'zigzag': { const d = tr.reach * there; return out(d, Math.sin(u * Math.PI * 6) * 12); }
      case 'cradle': { const sw = Math.sin(u * Math.PI * 4) * 0.9; return { x: Math.sin(sw) * tr.reach * f, y: -6 + Math.cos(sw) * 8 }; }
      case 'uppercut': return out(tr.reach * 0.5 * there, 0, tr.reach * there);
      case 'split': { const ang = a + Math.sin(u * Math.PI) * Math.PI * 1.5 * f - Math.PI * 0.75 * f * there; return { x: Math.cos(ang) * tr.reach * there, y: Math.sin(ang) * tr.reach * 0.6 * there }; }
      case 'atomic': { const ang = u * Math.PI * 2 * 3 * f; const r = tr.reach * Math.sin(u * Math.PI); return { x: Math.cos(ang) * r, y: Math.sin(ang * 1.5) * r * 0.6 }; }
      case 'orbit': { const ang = u * Math.PI * 2 * 4 * f; return { x: Math.cos(ang) * tr.reach, y: Math.sin(ang) * tr.reach * 0.65 }; }
    }
    return { x: 0, y: 6 };
  }

  update(dt: number, hx: number, hy: number) {
    this.hand = { x: hx, y: hy };
    this.prev = { ...this.pos };
    if (this.trick) {
      this.t += dt;
      // holding RMB keeps the orbit storm spinning (resets its clock to the middle)
      if (this.trick.id === 'orbit' && this.hold && this.t > this.trick.dur * 0.7) this.t = this.trick.dur * 0.3;
      if (this.t >= this.trick.dur) this.trick = null;
    }
    const o = this.offset();
    this.pos = { x: hx + o.x, y: hy + o.y };
    this.spin += dt * (this.trick ? 40 : 18);
    this.trail.unshift({ ...this.pos });
    if (this.trail.length > (this.trick ? 9 : 3)) this.trail.pop();
  }
  speed(dt: number) { return Math.hypot(this.pos.x - this.prev.x, this.pos.y - this.prev.y) / Math.max(dt, 1e-3); }

  draw(ctx: Ctx, accent: string, time: number) {
    const { hand, pos } = this;
    // motion trail (glowing ring blur)
    for (let i = this.trail.length - 1; i >= 1; i--) {
      const k = 1 - i / this.trail.length;
      ctx.globalAlpha = k * 0.5;
      pline(ctx, this.trail[i].x, this.trail[i].y, this.trail[i - 1].x, this.trail[i - 1].y, accent, Math.max(1, Math.round(k * 3)));
    }
    ctx.globalAlpha = 1;
    // string: slight sag when slack, tight when thrown
    const tight = this.trick ? 1 : 0;
    const mx = (hand.x + pos.x) / 2, my = (hand.y + pos.y) / 2 + (1 - tight) * 3;
    ctx.globalAlpha = 0.85;
    pline(ctx, hand.x, hand.y, mx, my, '#f2f2f2', 1); pline(ctx, mx, my, pos.x, pos.y, '#f2f2f2', 1);
    ctx.globalAlpha = 1;
    // the yoyo: black rim, two-tone body, spinning highlight
    pcircle(ctx, pos.x, pos.y, 3.5, '#000');
    pcircle(ctx, pos.x, pos.y, 2.6, '#e8364f');
    const ang = this.spin;
    prect(ctx, Math.round(pos.x + Math.cos(ang) * 1.6), Math.round(pos.y + Math.sin(ang) * 1.6), 1, 1, '#ffffff');
    prect(ctx, Math.round(pos.x - Math.cos(ang) * 1.6), Math.round(pos.y - Math.sin(ang) * 1.6), 1, 1, '#7a0f1f');
    prect(ctx, Math.round(pos.x), Math.round(pos.y), 1, 1, '#ffd27f');
    if (this.trick && (this.trick.finisher || Math.floor(time * 30) % 2 === 0)) { ctx.globalAlpha = 0.3; pcircle(ctx, pos.x, pos.y, 5, accent); ctx.globalAlpha = 1; }
  }
}

export function drawYoyoIcon(ctx: Ctx, x: number, y: number) {
  pline(ctx, x - 5, y - 6, x + 2, y + 1, '#f2f2f2', 1);
  pcircle(ctx, x + 3, y + 2, 3.5, '#000'); pcircle(ctx, x + 3, y + 2, 2.5, '#e8364f');
}
