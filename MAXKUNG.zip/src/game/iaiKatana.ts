import { pcircle, pline, px, type Ctx } from './pixel';
import type { Vec } from './types';

export type IaiStance = 'cane' | 'ready';
export const IAI_BLADE_LENGTH = 26;

export function iaiBlade(hand: Vec, angle: number, lift = 0) {
  return {
    base: hand,
    tip: { x: hand.x + Math.cos(angle) * IAI_BLADE_LENGTH, y: hand.y + Math.sin(angle) * IAI_BLADE_LENGTH * 0.6 - lift * 10 },
  };
}

export function drawIaiCane(ctx: Ctx, right: Vec, left: Vec, groundY: number) {
  const x = (right.x + left.x) / 2;
  const top = Math.min(right.y, left.y) - 3;
  const bottom = Math.max(groundY + 1, top + 13);
  pline(ctx, x, top, x, bottom, '#07080c', 3);
  pline(ctx, x, top + 4, x, bottom - 1, '#46505e', 1);
  pline(ctx, x, top, x, top + 4, '#302b2e', 2);
  px(ctx, x, top + 1, '#d8d2bc');
  pline(ctx, x - 2, top + 5, x + 2, top + 5, '#c4a76c', 1);
  px(ctx, x, bottom, '#a9b5c0');
  pcircle(ctx, left.x, left.y, 1, '#e7e6df');
  pcircle(ctx, right.x, right.y, 1, '#f3f1eb');
}

export function drawIaiSaya(ctx: Ctx, right: Vec, left: Vec, facing: number, drawn: boolean) {
  const mouth = { x: left.x, y: left.y };
  const tip = { x: mouth.x - facing * 16, y: mouth.y + 5 };
  pline(ctx, mouth.x, mouth.y, tip.x, tip.y, '#06070b', 3);
  pline(ctx, mouth.x, mouth.y, tip.x, tip.y, '#47505d', 1);
  px(ctx, tip.x, tip.y, '#a9b5c0');
  pline(ctx, mouth.x - facing * 1.5, mouth.y - 1, mouth.x - facing * 1.5, mouth.y + 1, '#bd9e62', 1);
  if (!drawn) {
    pline(ctx, mouth.x, mouth.y, right.x, right.y, '#191c23', 2);
    px(ctx, (mouth.x + right.x) / 2, (mouth.y + right.y) / 2, '#e0d9cb');
    pcircle(ctx, left.x, left.y, 1, '#e7e6df');
    pcircle(ctx, right.x, right.y, 1, '#f3f1eb');
  }
}