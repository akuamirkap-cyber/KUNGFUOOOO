import { pline, type Ctx } from './pixel';
import type { Vec } from './types';
import { AXE_LEN, drawAxe } from './weapons';

type AxePhase = 'held' | 'outbound' | 'returning';
type TrailPoint = Vec & { life: number };

export class AxeFlight {
  phase: AxePhase = 'held';
  position: Vec = { x: 0, y: 0 };
  velocity: Vec = { x: 0, y: 0 };
  distance = 0;
  spin = 0;
  hitIds = new Set<number>();
  trail: TrailPoint[] = [];

  get active() { return this.phase !== 'held'; }

  reset() {
    this.phase = 'held';
    this.hitIds.clear();
    this.trail = [];
  }

  launch(origin: Vec, aim: number) {
    this.phase = 'outbound';
    this.position = { ...origin };
    this.velocity = { x: Math.cos(aim) * 400, y: Math.sin(aim) * 400 };
    this.distance = 0;
    this.spin = aim;
    this.hitIds.clear();
    this.trail = [];
  }

  recall() { if (this.active) this.phase = 'returning'; }

  update(dt: number, hand: Vec, canMove: (x: number, y: number) => boolean) {
    if (!this.active) return null;
    const from = { ...this.position };
    let caught = false;
    if (this.phase === 'outbound') {
      const dx = this.velocity.x * dt, dy = this.velocity.y * dt;
      const steps = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 5));
      for (let i = 1; i <= steps; i++) {
        const next = { x: from.x + dx * i / steps, y: from.y + dy * i / steps };
        if (!canMove(next.x, next.y)) { this.recall(); break; }
        this.position = next;
      }
      this.distance += Math.hypot(this.position.x - from.x, this.position.y - from.y);
      if (this.distance >= 150) this.recall();
    } else {
      const dx = hand.x - this.position.x, dy = hand.y - this.position.y;
      const distance = Math.hypot(dx, dy);
      const step = 520 * dt;
      if (distance <= step + 4) {
        this.position = { ...hand };
        this.phase = 'held';
        caught = true;
      } else {
        this.position = { x: this.position.x + dx / distance * step, y: this.position.y + dy / distance * step };
      }
    }
    this.spin += dt * 16;
    for (const point of this.trail) point.life -= dt;
    this.trail = this.trail.filter((point) => point.life > 0);
    if (!caught && Math.hypot(this.position.x - from.x, this.position.y - from.y) > 1) {
      this.trail.push({ ...from, life: 0.1 });
      if (this.trail.length > 5) this.trail.shift();
    }
    return { from, to: { ...this.position }, caught };
  }

  draw(ctx: Ctx) {
    if (!this.active) return;
    const alpha = ctx.globalAlpha;
    for (let i = 1; i < this.trail.length; i++) {
      const a = this.trail[i - 1], b = this.trail[i];
      ctx.globalAlpha = alpha * Math.min(0.22, b.life * 2.2);
      pline(ctx, a.x, a.y, b.x, b.y, '#b3b8b6', 1);
    }
    ctx.globalAlpha = alpha;
    const base = { x: this.position.x - Math.cos(this.spin) * AXE_LEN * 0.5, y: this.position.y - Math.sin(this.spin) * AXE_LEN * 0.3 };
    drawAxe(ctx, base, this.spin);
  }
}