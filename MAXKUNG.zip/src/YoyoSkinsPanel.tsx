import { useEffect, useRef, type CSSProperties, type KeyboardEvent, type RefObject } from 'react';
import { ArrowRight, ArrowUpRight, Check, Download, X } from 'lucide-react';
import { drawYoyoSprite, Yoyo } from './game/yoyo';
import { getYoyoSkin, YOYO_SKINS, type YoyoSkinId } from './game/yoyoSkins';

type SkinProps = { selected: YoyoSkinId; onSelect: (id: YoyoSkinId) => void };

function skinStyle(color: string): CSSProperties {
  return { '--skin-accent': color } as CSSProperties;
}

export function YoyoSkinEmblem({ id, large = false }: { id: YoyoSkinId; large?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(6.5, 0, 0, 6.5, 48, 48);
    drawYoyoSprite(ctx, 0, 0, getYoyoSkin(id), 1.2, false);
  }, [id]);
  return <canvas ref={canvasRef} width={96} height={96} className={`skin-emblem ${large ? 'skin-emblem-large' : ''}`} aria-hidden="true" />;
}

export function YoyoTrailPreview({ id }: { id: YoyoSkinId }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const yoyo = new Yoyo();
    yoyo.setSkin(id);
    yoyo.reset(46, 0);
    const hand = { x: 0, y: 0 };
    for (let i = 0; i < 28; i++) yoyo.update(1 / 60, hand, hand, 0, 'y_orbit', 'active', 0.48, 54);
    let frame = 0;
    let last = performance.now();
    const render = (now: number) => {
      const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
      last = now;
      yoyo.update(dt, hand, hand, 0, 'y_orbit', 'active', 0.48, 54);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.setTransform(1.8, 0, 0, 1.8, canvas.width / 2, canvas.height / 2);
      ctx.fillStyle = yoyo.skin.trim;
      ctx.globalAlpha = 0.45;
      ctx.fillRect(-1, -1, 2, 2);
      ctx.globalAlpha = 1;
      yoyo.draw(ctx, true, hand);
      frame = requestAnimationFrame(render);
    };
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      render(last);
      cancelAnimationFrame(frame);
    } else frame = requestAnimationFrame(render);
    return () => cancelAnimationFrame(frame);
  }, [id]);
  return <canvas ref={canvasRef} width={560} height={220} className="skin-trail-canvas" role="img" aria-label={`Pratinjau trail ${getYoyoSkin(id).name}`} />;
}

export function YoyoSkinChoices({ selected, onSelect }: SkinProps) {
  return (
    <div className="skin-choices" role="group" aria-label="Pilih skin yo-yo">
      {YOYO_SKINS.map((skin, index) => (
        <button
          key={skin.id}
          type="button"
          className="skin-choice"
          style={skinStyle(skin.accent)}
          aria-label={`Pilih skin ${skin.name}`}
          aria-pressed={selected === skin.id}
          onClick={() => onSelect(skin.id)}
        >
          <YoyoSkinEmblem id={skin.id} />
          <span className="skin-choice-copy"><small>0{index + 1} / {skin.shapeLabel}</small><strong>{skin.name}</strong><span>{skin.description}</span></span>
          <span className="skin-choice-icon" aria-hidden="true">{selected === skin.id ? <Check size={15} /> : <ArrowUpRight size={14} />}</span>
        </button>
      ))}
    </div>
  );
}

export function YoyoSkinSpotlight({ id }: { id: YoyoSkinId }) {
  const skin = getYoyoSkin(id);
  return (
    <div className="skin-spotlight" style={skinStyle(skin.accent)}>
      <YoyoTrailPreview id={id} />
      <div className="skin-spotlight-caption"><span>TRAIL PREVIEW</span><strong>{skin.name}</strong></div>
    </div>
  );
}

export function renderYoyoAsset(id: YoyoSkinId, kind: 'skin' | 'trail') {
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;
  if (kind === 'skin') {
    ctx.setTransform(16, 0, 0, 16, 128, 128);
    drawYoyoSprite(ctx, 0, 0, getYoyoSkin(id), 1.2, false);
  } else {
    const yoyo = new Yoyo();
    yoyo.setSkin(id);
    yoyo.reset(46, 0);
    const hand = { x: 0, y: 0 };
    for (let i = 0; i < 28; i++) yoyo.update(1 / 60, hand, hand, 0, 'y_orbit', 'active', 0.48, 54);
    ctx.setTransform(2.2, 0, 0, 2.2, 128, 128);
    yoyo.draw(ctx, true, hand);
  }
  return canvas;
}

function downloadYoyoPng(id: YoyoSkinId, kind: 'skin' | 'trail') {
  const canvas = renderYoyoAsset(id, kind);
  const link = document.createElement('a');
  link.download = `yoyo-${id}${kind === 'trail' ? '-trail' : ''}.png`;
  link.href = canvas.toDataURL('image/png');
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export function YoyoSkinDialog({ selected, onSelect, onClose, closeRef }: SkinProps & { onClose: () => void; closeRef: RefObject<HTMLButtonElement | null> }) {
  const skin = getYoyoSkin(selected);
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    event.stopPropagation();
    if (event.key === 'Escape') { event.preventDefault(); onClose(); return; }
    if (event.key !== 'Tab') return;
    const focusable = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], [tabindex]:not([tabindex="-1"])'));
    if (!focusable.length) return;
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  };
  return (
    <div className="guide-backdrop" onClick={onClose} onKeyDown={onKeyDown}>
      <div className="skin-dialog" role="dialog" aria-modal="true" aria-labelledby="skin-dialog-title" onClick={(event) => event.stopPropagation()}>
        <div className="dialog-top"><div><div className="eyebrow"><span className="eyebrow-line" /> YO-YO SKIN LAB</div><h2 id="skin-dialog-title">PILIH SKIN<span>.</span></h2></div><button ref={closeRef} type="button" onClick={onClose} aria-label="Tutup pilihan skin"><X size={20} /></button></div>
        <p>Pilih bentuk dan warna trail. Semua skin hanya mengubah tampilan.</p>
        <div className="skin-dialog-layout">
          <div className="skin-dialog-preview" style={skinStyle(skin.accent)}>
            <YoyoSkinEmblem id={selected} large />
            <div className="skin-dialog-name"><span>SELECTED SKIN</span><strong>{skin.name}</strong><small>{skin.description}</small></div>
            <YoyoSkinSpotlight id={selected} />
            <div className="skin-downloads"><button className="skin-download" type="button" onClick={() => downloadYoyoPng(selected, 'skin')}><Download size={14} /> PNG SKIN</button><button className="skin-download" type="button" onClick={() => downloadYoyoPng(selected, 'trail')}><Download size={14} /> PNG TRAIL</button></div>
            <small className="skin-export-note">PNG transparan; trail adalah cuplikan statis.</small>
          </div>
          <YoyoSkinChoices selected={selected} onSelect={onSelect} />
        </div>
        <button className="skin-done" type="button" onClick={onClose}>SELESAI <ArrowRight size={15} /></button>
      </div>
    </div>
  );
}