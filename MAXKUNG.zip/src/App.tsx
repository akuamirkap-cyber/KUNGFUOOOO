import { useCallback, useEffect, useRef, useState, type PointerEvent, type ReactNode, type RefObject } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowUpRight,
  Axe,
  Crosshair,
  ExternalLink,
  Gamepad2,
  GitBranch,
  Maximize2,
  Minimize2,
  MousePointer2,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Swords,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { VIEW_H, VIEW_W, ZONES } from './game/constants';
import { Game, type UIState } from './game/game';
import { getYoyoSkin, type YoyoSkinId } from './game/yoyoSkins';
import { YoyoSkinChoices, YoyoSkinDialog, YoyoSkinSpotlight } from './YoyoSkinsPanel';

const initialUI: UIState = {
  state: 'menu', level: 1, zoneName: ZONES[0].name, zoneSub: ZONES[0].sub,
  score: 0, age: 20, deathCounter: 1, deaths: 0, kills: 0, bestCombo: 0,
  choices: [], save: null, best: { level: 0, score: 0 }, muted: false,
  mutations: [], ageGain: 0, hp: 5, maxHp: 5, accent: '#ff5a36',
  mode: 'story', wave: 0, survivalTime: 0, bestWave: 0, bestSurvivalScore: 0, weapon: 'fist', yoyoSkin: 'ember', iaiStance: 'cane',
  blood: 'combined', v2: true, long: false,
};

const controlDetails = [
  ['W / A / S / D', 'Bergerak; tahan untuk berlari'],
  ['MOUSE', 'Arahkan serangan'],
  ['KLIK KIRI / J', 'Serangan ringan dan kombo'],
  ['KLIK KANAN / K', 'Serangan berat'],
  ['6', 'Pilih axe Viking, siap sejak awal'],
  ['TAHAN KIRI / J', 'Axe: empat ayunan berantai'],
  ['KANAN / K', 'Axe: ayunan berat dan putaran'],
  ['LARI + KIRI / J', 'Axe: dorongan maju dengan ayunan'],
  ['G', 'Axe: lempar atau tarik kembali'],
  ['9', 'Pilih katana master, siap sejak awal'],
  ['T', 'Katana: ganti sikap tongkat / siap cabut'],
  ['KLIK KIRI / J', 'Katana: satu tebasan, lepas untuk mengulang'],
  ['KANAN / K', 'Katana: satu iaijutsu flash step'],
  ['G', 'Katana: variasi gaya pedang tanpa menyerang'],
  ['8', 'Pilih yo-yo freestyle, siap sejak awal'],
  ['TAHAN KIRI / J', 'Yo-yo: kombo toprock, windmill, dan flare'],
  ['TAHAN KANAN / K', 'Yo-yo: breakdance spin terus-menerus'],
  ['KIRI, KANAN', 'Yo-yo: freeze dan trapeze'],
  ['SPACE', 'Lompat'],
  ['SHIFT', 'Shadow step / menghindar'],
  ['C', 'Parry'],
  ['E', 'Focus strike'],
  ['R', 'Rage saat meter penuh'],
  ['X', 'One For All saat energi tersedia'],
  ['F', 'Fatality'],
  ['Q / 1-9 / SCROLL', 'Ganti senjata'],
  ['B', 'Ganti efek darah'],
  ['V', 'Ganti tampilan V1 / V2'],
  ['L', 'Mode long limbs'],
  ['ESC / P', 'Jeda permainan'],
];

function aimAtNearest(game: Game) {
  if (game.input.mouseMovedAt > 0 && performance.now() - game.input.mouseMovedAt < 1500) return;
  const player = game.player;
  let closest = null;
  let distance = Infinity;
  for (const enemy of game.enemies) {
    if (enemy.dead || enemy.spawnT > 0) continue;
    const next = (enemy.x - player.x) ** 2 + (enemy.y - player.y) ** 2;
    if (next < distance) {
      distance = next;
      closest = enemy;
    }
  }
  if (!closest) return;
  game.input.mouse.x = (closest.x - game.cam.x - VIEW_W / 2) * game.zoom + VIEW_W / 2;
  game.input.mouse.y = (closest.y - game.cam.y - VIEW_H / 2) * game.zoom + VIEW_H / 2;
}

function Keycap({ children }: { children: ReactNode }) {
  return <kbd className="keycap">{children}</kbd>;
}

function TouchButton({
  label,
  children,
  onPress,
  onRelease,
  className = '',
}: {
  label: string;
  children: ReactNode;
  onPress: () => void;
  onRelease: () => void;
  className?: string;
}) {
  const held = useRef(false);
  const release = () => {
    if (!held.current) return;
    held.current = false;
    onRelease();
  };
  const press = (event: PointerEvent<HTMLButtonElement>) => {
    event.preventDefault();
    if (held.current) return;
    held.current = true;
    event.currentTarget.setPointerCapture(event.pointerId);
    onPress();
  };
  return (
    <button
      type="button"
      className={`touch-button ${className}`}
      aria-label={label}
      onPointerDown={press}
      onPointerUp={release}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onClick={(event) => {
        if (event.detail === 0) {
          onPress();
          window.setTimeout(onRelease, 120);
        }
      }}
    >
      {children}
    </button>
  );
}

function TouchControls({ gameRef, weapon }: { gameRef: RefObject<Game | null>; weapon: UIState['weapon'] }) {
  const sendKey = (code: string, down: boolean) => {
    const game = gameRef.current;
    if (!game) return;
    if (down && (code === 'KeyJ' || code === 'KeyK')) aimAtNearest(game);
    game.input.focus();
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, bubbles: true }));
  };
  const button = (code: string, label: string, content: ReactNode, className = '') => (
    <TouchButton
      label={label}
      className={className}
      onPress={() => sendKey(code, true)}
      onRelease={() => sendKey(code, false)}
    >
      {content}
    </TouchButton>
  );
  return (
    <div className="touch-controls" aria-label="Kontrol sentuh">
      <div className="touch-direction">
        {button('KeyW', 'Bergerak ke atas', <ArrowUp size={18} />, 'direction-up')}
        {button('KeyA', 'Bergerak ke kiri', <ArrowLeft size={18} />, 'direction-left')}
        {button('KeyS', 'Bergerak ke bawah', <ArrowDown size={18} />, 'direction-down')}
        {button('KeyD', 'Bergerak ke kanan', <ArrowRight size={18} />, 'direction-right')}
      </div>
      <div className="touch-caption"><Gamepad2 size={17} /><span>KONTROL<br />SENTUH</span></div>
      <div className="touch-actions">
        {button('ShiftLeft', 'Menghindar', 'DASH', 'touch-small')}
        {button('Space', 'Lompat', 'LOMPAT', 'touch-small')}
        {button('KeyK', weapon === 'yoyo' ? 'Breakdance yo-yo, tahan' : weapon === 'iaikatana' ? 'Flash step katana' : weapon === 'axe' ? 'Ayunan berat axe' : 'Serangan berat', weapon === 'yoyo' ? 'DANCE' : weapon === 'iaikatana' ? 'IAI' : 'BERAT', 'touch-heavy')}
        {button('KeyJ', weapon === 'yoyo' ? 'Lempar yo-yo, tahan' : weapon === 'iaikatana' ? 'Satu tebasan katana' : weapon === 'axe' ? 'Kombo axe, tahan' : 'Serangan ringan', weapon === 'yoyo' ? 'LEMPAR' : weapon === 'iaikatana' ? 'TEBAS' : weapon === 'axe' ? 'AYUN' : 'PUKUL', 'touch-attack')}
        {button('KeyE', 'Focus strike', 'FOCUS', 'touch-small')}
        {button('KeyX', 'One For All', 'OFA', 'touch-small')}
        {weapon === 'iaikatana' && button('KeyT', 'Ganti sikap katana', 'SIKAP', 'touch-stance')}
        {weapon === 'iaikatana' && button('KeyG', 'Gaya putar katana', 'GAYA', 'touch-style')}
        {weapon === 'axe' && button('KeyG', 'Lempar atau tarik axe', 'LEMPAR / TARIK AXE', 'touch-axe')}
      </div>
    </div>
  );
}

function GameOverlay({ ui, gameRef }: { ui: UIState; gameRef: RefObject<Game | null> }) {
  const game = () => gameRef.current;
  if (ui.state === 'menu') {
    return (
      <div className="game-menu">
        <div className="menu-art" />
        <div className="menu-shade" />
        <div className="screen-scanlines" />
        <div className="menu-content">
          <div className="screen-kicker"><span /> A 2D KUNG FU ROGUELITE</div>
          <h2 className="screen-title"><span>KUNGFU</span><span>DRIFTER<span className="title-period">.</span></span></h2>
          <div className="screen-subtitle">200 FLOORS <span>/</span> ONE FIST</div>
          <p className="screen-description">Pilih bentuk yo-yo favorit dan buat setiap gerakan meninggalkan trail yang indah.</p>
          <div className="menu-buttons">
            <button className="start-button" type="button" onClick={() => game()?.newGame(null)}>
              <Play size={15} fill="currentColor" /> <span>MAIN STORY</span> <ArrowRight size={15} />
            </button>
            <button className="survival-button" type="button" onClick={() => game()?.newSurvival()}>
              SURVIVAL <ArrowUpRight size={15} />
            </button>
          </div>
          {ui.save && ui.save.level > 1 && (
            <button className="continue-button" type="button" onClick={() => game()?.newGame(ui.save)}>
              LANJUTKAN DARI LANTAI {ui.save.level} <ArrowRight size={13} />
            </button>
          )}
          <div className="menu-hint"><span className="tiny-square" /> TEKAN ENTER UNTUK MEMULAI</div>
        </div>
        <div className="menu-index" aria-hidden="true">KD / 02</div>
      </div>
    );
  }

  if (ui.state === 'playing') return null;

  if (ui.state === 'mutation') {
    return (
      <div className="game-state-overlay">
        <div className="state-content mutation-content">
          <div className="state-kicker">{ui.mode === 'survival' ? `WAVE ${ui.wave} SELESAI` : `LANTAI ${ui.level} SELESAI`}</div>
          <h2>PILIH MUTASI</h2>
          <p>Pilih satu kemampuan untuk melanjutkan.</p>
          <div className="mutation-choices">
            {ui.choices.map((mutation, index) => (
              <button type="button" key={mutation.id} className="mutation-choice" onClick={() => game()?.chooseMutation(index)}>
                <span className="mutation-number">0{index + 1}</span>
                <strong style={{ color: mutation.color }}>{mutation.name}</strong>
                <span>{mutation.desc}</span>
                <small>TEKAN {index + 1}</small>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (ui.state === 'paused') {
    return (
      <div className="game-state-overlay">
        <div className="state-content">
          <div className="state-kicker">TARIK NAPAS SEJENAK</div>
          <h2>PAUSED<span>.</span></h2>
          <p>{ui.mode === 'survival' ? `SURVIVAL / WAVE ${ui.wave}` : `LANTAI ${ui.level} / ${ui.zoneName}`}</p>
          <div className="state-actions">
            <button className="start-button" type="button" onClick={() => game()?.resume()}><Play size={14} fill="currentColor" /> LANJUTKAN</button>
            <button className="survival-button" type="button" onClick={() => game()?.toMenu()}>MENU UTAMA</button>
          </div>
          <small>TEKAN ESC UNTUK LANJUT</small>
        </div>
      </div>
    );
  }

  if (ui.state === 'dead') {
    return (
      <div className="game-state-overlay death-overlay">
        <div className="state-content">
          <div className="state-kicker">PERTARUNGAN BELUM SELESAI</div>
          <h2>YOU DIED<span>.</span></h2>
          <p>{ui.mode === 'survival' ? `BERTAHAN SELAMA ${ui.wave} WAVE` : `USIA ${ui.age} MENJADI ${ui.age + ui.ageGain}. LEBIH TUA, LEBIH KUAT.`}</p>
          <button className="start-button" type="button" onClick={() => game()?.respawn()}>{ui.mode === 'survival' ? 'LIHAT HASIL' : 'BANGKIT LAGI'} <ArrowRight size={15} /></button>
          <small>TEKAN ENTER UNTUK MELANJUTKAN</small>
        </div>
      </div>
    );
  }

  const won = ui.state === 'victory';
  return (
    <div className="game-state-overlay">
      <div className="state-content">
        <div className="state-kicker">{won ? 'THE JOURNEY IS COMPLETE' : 'AKHIR PERJALANAN'}</div>
        <h2>{won ? 'THE MASTER' : 'GAME OVER'}<span>.</span></h2>
        <p>{ui.mode === 'survival' ? `WAVE ${ui.wave} / ${ui.score} POIN` : `LANTAI ${ui.level} / ${ui.score} POIN`}</p>
        <div className="state-actions">
          {!won && <button className="start-button" type="button" onClick={() => game()?.restartZone()}>COBA LAGI <RotateCcw size={14} /></button>}
          <button className="survival-button" type="button" onClick={() => game()?.toMenu()}>MENU UTAMA</button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const screenRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const guideCloseRef = useRef<HTMLButtonElement>(null);
  const pausedForGuide = useRef(false);
  const skinCloseRef = useRef<HTMLButtonElement>(null);
  const skinTriggerRef = useRef<HTMLButtonElement>(null);
  const pausedForSkins = useRef(false);
  const [ui, setUi] = useState<UIState>(initialUI);
  const [screenWidth, setScreenWidth] = useState(VIEW_W);
  const [showGuide, setShowGuide] = useState(false);
  const [showSkins, setShowSkins] = useState(false);
  const [showTouch, setShowTouch] = useState(() => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches);
  const [fullscreen, setFullscreen] = useState(false);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let game: Game;
    try {
      game = new Game(canvas);
      gameRef.current = game;
      (window as Window & { __kf?: Game }).__kf = game;
      game.onUI = setUi;
      game.start();
    } catch (error) {
      console.error('[KUNGFU DRIFTER] Gagal memuat game:', error);
      setLoadError(true);
      return;
    }
    const assistKeyboard = (event: KeyboardEvent) => {
      if (event.code === 'KeyJ' || event.code === 'KeyK') aimAtNearest(game);
    };
    const pauseWhenHidden = () => {
      if (document.hidden && game.state === 'playing') game.pause();
    };
    window.addEventListener('keydown', assistKeyboard);
    document.addEventListener('visibilitychange', pauseWhenHidden);
    return () => {
      window.removeEventListener('keydown', assistKeyboard);
      document.removeEventListener('visibilitychange', pauseWhenHidden);
      game.destroy();
      if (gameRef.current === game) gameRef.current = null;
      if ((window as Window & { __kf?: Game }).__kf === game) delete (window as Window & { __kf?: Game }).__kf;
    };
  }, []);

  useEffect(() => {
    const screen = screenRef.current;
    if (!screen) return;
    const measure = () => setScreenWidth(screen.getBoundingClientRect().width || VIEW_W);
    measure();
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(measure);
    observer?.observe(screen);
    window.addEventListener('resize', measure);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, []);

  useEffect(() => {
    const onFullscreenChange = () => setFullscreen(document.fullscreenElement === playerRef.current);
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', onFullscreenChange);
  }, []);

  useEffect(() => {
    if (showGuide) guideCloseRef.current?.focus();
  }, [showGuide]);

  useEffect(() => {
    if (showSkins) skinCloseRef.current?.focus();
  }, [showSkins]);

  const openGuide = () => {
    pausedForGuide.current = gameRef.current?.state === 'playing';
    if (pausedForGuide.current) gameRef.current?.pause();
    setShowGuide(true);
  };
  const closeGuide = useCallback(() => {
    setShowGuide(false);
    if (pausedForGuide.current && gameRef.current?.state === 'paused') gameRef.current.resume();
    pausedForGuide.current = false;
  }, []);

  const openSkins = () => {
    pausedForSkins.current = gameRef.current?.state === 'playing';
    if (pausedForSkins.current) gameRef.current?.pause();
    setShowSkins(true);
  };
  const closeSkins = useCallback(() => {
    setShowSkins(false);
    if (pausedForSkins.current && gameRef.current?.state === 'paused') gameRef.current.resume();
    else if (gameRef.current?.state === 'paused') gameRef.current.input.focus();
    else skinTriggerRef.current?.focus();
    pausedForSkins.current = false;
  }, []);
  const selectSkin = (id: YoyoSkinId, focusGame = false) => {
    const game = gameRef.current;
    if (!game) return;
    game.setYoyoSkin(id);
    if (focusGame && game.state === 'playing') game.input.focus();
  };

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await playerRef.current?.requestFullscreen();
      gameRef.current?.input.focus();
    } catch (error) {
      console.error('[KUNGFU DRIFTER] Layar penuh tidak tersedia:', error);
    }
  };

  const togglePlay = () => {
    const game = gameRef.current;
    if (!game) return;
    if (game.state === 'menu') game.newGame(null);
    else if (game.state === 'playing') game.pause();
    else if (game.state === 'paused') game.resume();
    game.input.focus();
  };

  const restart = () => {
    const game = gameRef.current;
    if (!game || game.state === 'menu') return;
    if (game.mode === 'survival') game.newSurvival();
    else game.newGame(null);
    game.input.focus();
  };

  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const canvasWidth = ui.v2 ? Math.max(VIEW_W, Math.min(1920, Math.round(screenWidth * dpr))) : VIEW_W;
  const canvasHeight = ui.v2 ? Math.round(canvasWidth * VIEW_H / VIEW_W) : VIEW_H;
  const status = ui.state === 'playing' ? 'SEDANG BERMAIN' : ui.state === 'paused' ? 'GAME DIJEDA' : 'GAME SIAP';
  const selectedSkin = getYoyoSkin(ui.yoyoSkin);
  const guideWeapon = ui.state === 'menu' ? 'yoyo' : ui.weapon;

  return (
    <div className="site" id="top">
      <header className="site-header">
        <div className="header-inner">
          <a className="brand" href="#top" aria-label="Kungfu Drifter Arcade">
            <span className="brand-mark"><Swords size={21} strokeWidth={2.1} /></span>
            <span className="brand-copy"><strong>DRIFTER</strong><small>ARCADE CLUB</small></span>
          </a>
          <div className="header-center"><span /> THE FIGHT STARTS HERE <span /></div>
          <div className="header-right">
            <div className="online-label"><i /> GAME ONLINE</div>
            <a className="source-link" href="https://github.com/akuamirkap-cyber/OPUS-KUNGFU" target="_blank" rel="noreferrer" aria-label="Lihat kode sumber di GitHub"><GitBranch size={16} /><span>GITHUB</span><ExternalLink size={12} /></a>
          </div>
        </div>
      </header>

      <main className="page-content">
        <div className="page-heading">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" /> THE ARCADE <span className="slash">/</span> ACTION ROGUELITE</div>
            <h1>KUNGFU <span>DRIFTER</span></h1>
            <p>200 lantai. Satu petarung. Yo-yo freestyle, empat skin berbeda.</p>
          </div>
          <div className="heading-meta"><span className="heading-meta-icon"><Crosshair size={18} /></span><div><strong>SIAP BERTARUNG?</strong><small>PLAYER 01 / LET'S GO</small></div></div>
        </div>

        <div className="workspace">
          <section className="player-column" aria-label="Game Kungfu Drifter">
            <div className="game-player" ref={playerRef}>
              <div className="player-topbar">
                <div className="player-top-title"><span className="topbar-mark">K<span>D</span></span><strong>KUNGFU DRIFTER</strong><span className="topbar-separator">/</span><span className="topbar-dim">200 FLOORS OF PAIN</span></div>
                <div className="player-status"><span className="status-dot" /> {status}</div>
              </div>
              <div className="game-screen" ref={screenRef}>
                <canvas
                  ref={canvasRef}
                  width={canvasWidth}
                  height={canvasHeight}
                  tabIndex={0}
                  className="game-canvas"
                  aria-label="Arena game Kungfu Drifter"
                  onContextMenu={(event) => event.preventDefault()}
                />
                <div className="game-scanlines" />
                {loadError ? (
                  <div className="game-state-overlay"><div className="state-content"><h2>GAGAL MEMUAT<span>.</span></h2><p>Browser ini tidak dapat menjalankan game. Coba muat ulang halaman.</p><button className="start-button" type="button" onClick={() => window.location.reload()}>MUAT ULANG</button></div></div>
                ) : <GameOverlay ui={ui} gameRef={gameRef} />}
              </div>
              <div className="player-toolbar">
                <div className="toolbar-caption">
                  <button type="button" className={`weapon-select weapon-axe ${ui.weapon === 'axe' && ui.state !== 'menu' ? 'weapon-active' : ''}`} disabled={ui.state !== 'playing' && ui.state !== 'paused'} onClick={() => { gameRef.current?.setWeapon('axe'); gameRef.current?.input.focus(); }} aria-label="Pakai axe Viking" aria-pressed={ui.weapon === 'axe' && ui.state !== 'menu'} title="Pakai axe Viking (6)"><Axe size={14} /> AXE <kbd>6</kbd></button>
                  <button type="button" className={`weapon-select weapon-iai ${ui.weapon === 'iaikatana' && ui.state !== 'menu' ? 'weapon-active' : ''}`} disabled={ui.state !== 'playing' && ui.state !== 'paused'} onClick={() => { gameRef.current?.setWeapon('iaikatana'); gameRef.current?.input.focus(); }} aria-label="Pakai katana master" aria-pressed={ui.weapon === 'iaikatana' && ui.state !== 'menu'} title="Pakai katana master (9)"><span className="weapon-blade" /> KATANA <kbd>9</kbd></button>
                  <button type="button" className={`weapon-select ${guideWeapon === 'yoyo' ? 'weapon-active' : ''}`} disabled={ui.state !== 'playing' && ui.state !== 'paused'} onClick={() => { gameRef.current?.setWeapon('yoyo'); gameRef.current?.input.focus(); }} aria-label="Pakai yo-yo" aria-pressed={guideWeapon === 'yoyo'} title="Pakai yo-yo (8)"><span className="weapon-wheel" style={{ borderColor: selectedSkin.accent, background: selectedSkin.body }} /> YO-YO <kbd>8</kbd></button>
                  <button ref={skinTriggerRef} type="button" className="skin-open" onClick={openSkins} aria-label="Buka pilihan skin yo-yo"><Sparkles size={14} /><span>SKIN</span></button>
                  <span className="weapon-hint">{guideWeapon === 'yoyo' ? `${selectedSkin.name} / TAHAN KLIK KANAN UNTUK BREAKDANCE` : guideWeapon === 'iaikatana' ? 'SATU TEBASAN / G UNTUK GAYA' : 'G UNTUK LEMPAR / TARIK AXE'}</span>
                </div>
                <div className="toolbar-actions">
                  <button type="button" onClick={togglePlay} disabled={!['menu', 'playing', 'paused'].includes(ui.state)} aria-label={ui.state === 'playing' ? 'Jeda game' : 'Mulai atau lanjutkan game'} title={ui.state === 'playing' ? 'Jeda game' : 'Mulai atau lanjutkan game'}>{ui.state === 'playing' ? <Pause size={16} /> : <Play size={16} fill="currentColor" />}</button>
                  <button type="button" onClick={restart} disabled={ui.state === 'menu'} aria-label="Mulai ulang game" title="Mulai ulang game"><RotateCcw size={16} /></button>
                  <button type="button" onClick={() => { gameRef.current?.toggleMute(); gameRef.current?.input.focus(); }} aria-label={ui.muted ? 'Nyalakan suara' : 'Matikan suara'} title={ui.muted ? 'Nyalakan suara' : 'Matikan suara'}>{ui.muted ? <VolumeX size={17} /> : <Volume2 size={17} />}</button>
                  <button type="button" className={showTouch ? 'toolbar-selected' : ''} onClick={() => { setShowTouch((value) => !value); gameRef.current?.input.focus(); }} aria-label={showTouch ? 'Sembunyikan kontrol sentuh' : 'Tampilkan kontrol sentuh'} aria-pressed={showTouch} title="Kontrol sentuh"><Gamepad2 size={18} /></button>
                  <span className="toolbar-divider" />
                  <button type="button" onClick={toggleFullscreen} aria-label={fullscreen ? 'Keluar dari layar penuh' : 'Layar penuh'} title={fullscreen ? 'Keluar dari layar penuh' : 'Layar penuh'}>{fullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}</button>
                </div>
              </div>
              {showTouch && <TouchControls gameRef={gameRef} weapon={ui.weapon} />}
              {showSkins && <YoyoSkinDialog selected={ui.yoyoSkin} onSelect={(id) => selectSkin(id)} onClose={closeSkins} closeRef={skinCloseRef} />}
              {showGuide && (
                <div className="guide-backdrop" onClick={closeGuide} onKeyDown={(event) => { event.stopPropagation(); if (event.key === 'Escape') closeGuide(); }}>
                  <div className="guide-dialog" role="dialog" aria-modal="true" aria-labelledby="guide-title" onClick={(event) => event.stopPropagation()}>
                    <div className="dialog-top"><div><div className="eyebrow"><span className="eyebrow-line" /> PLAYER MANUAL</div><h2 id="guide-title">KONTROL LENGKAP<span>.</span></h2></div><button ref={guideCloseRef} type="button" onClick={closeGuide} aria-label="Tutup panduan"><X size={20} /></button></div>
                    <p>Klik layar game sebelum bermain. Gabungkan serangan untuk menemukan kombo baru.</p>
                    <div className="manual-grid">{controlDetails.map(([key, description]) => <div className="manual-row" key={`${key}-${description}`}><span>{description}</span><Keycap>{key}</Keycap></div>)}</div>
                    <div className="manual-note">TIP: Gunakan tombol kontrol sentuh di bawah layar untuk bermain tanpa keyboard.</div>
                  </div>
                </div>
              )}
            </div>
            <div className="under-player"><span><span className="under-red">*</span> BEST PLAYED WITH KEYBOARD &amp; MOUSE</span><span>MADE FOR THE FIGHT <span className="under-red">//</span> 01</span></div>
          </section>

          <aside className="skin-panel">
            <div className="section-label"><span>01 / YO-YO SKIN LAB</span><span className="section-label-end">+</span></div>
            <div className="skin-heading"><div><h2>PILIH<br /><span>SKIN YO-YO</span><b>.</b></h2><p>Bentuk berbeda, trail yang punya karakter.</p></div><span className="skin-heading-icon"><Sparkles size={20} /></span></div>
            <YoyoSkinSpotlight id={ui.yoyoSkin} />
            <YoyoSkinChoices selected={ui.yoyoSkin} onSelect={(id) => selectSkin(id, true)} />
            <button className="all-controls" type="button" onClick={openGuide}><span>LIHAT SEMUA KONTROL</span><ArrowRight size={16} /></button>
            <div className="guide-tip"><MousePointer2 size={15} /><div><strong>{guideWeapon === 'yoyo' ? 'B-BOY YO-YO FLOW' : guideWeapon === 'iaikatana' ? 'KATANA MASTER' : 'VIKING AXE FLOW'}</strong><p>{guideWeapon === 'yoyo' ? 'Tahan klik kiri untuk kombo toprock, windmill, dan flare. Tahan klik kanan untuk breakdance sambil menyerang!' : guideWeapon === 'iaikatana' ? 'Klik sekali untuk satu tebasan. Klik kanan untuk flash step, G untuk gaya, dan T untuk mengganti sikap.' : 'Tahan klik kiri untuk kombo, klik kanan untuk ayunan berat. Tekan G untuk melempar atau menarik axe kembali.'}</p></div></div>
            {ui.weapon === 'iaikatana' && <><button className="stance-switch" type="button" disabled={!['playing', 'paused'].includes(ui.state)} onClick={() => { gameRef.current?.toggleIaiStance(); gameRef.current?.input.focus(); }} aria-label="Ganti sikap katana"><span>SIKAP: {ui.iaiStance === 'cane' ? 'TONGKAT' : 'SIAP CABUT'}</span><Keycap>T</Keycap></button><button className="stance-switch flourish-switch" type="button" disabled={ui.state !== 'playing'} onClick={() => { gameRef.current?.playIaiFlourish(); gameRef.current?.input.focus(); }} aria-label="Gaya putar katana"><span>GAYA: AKSI PEDANG</span><Keycap>G</Keycap></button></>}
            {ui.weapon === 'axe' && <button className="stance-switch axe-action" type="button" disabled={ui.state !== 'playing'} onClick={() => { gameRef.current?.throwOrRecallAxe(); gameRef.current?.input.focus(); }} aria-label="Lempar atau tarik axe"><span>LEMPAR / TARIK AXE</span><Keycap>G</Keycap></button>}
          </aside>
        </div>
      </main>

      <footer className="site-footer"><span>THE DRIFTER ARCADE <span className="footer-red">//</span> KUNGFU DRIFTER</span><span>ONE FIST. ENDLESS FIGHTS.</span></footer>
    </div>
  );
}