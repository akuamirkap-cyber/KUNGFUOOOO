ASET SKIN YO-YO KUNGFU DRIFTER
================================

Setiap skin memiliki dua PNG transparan berukuran 256 x 256:

yoyo-ember.png           - cakram merah dan emas
yoyo-ember-trail.png     - cuplikan trail merah dan emas
yoyo-glacier.png         - bentuk butterfly biru es
yoyo-glacier-trail.png   - cuplikan pita trail biru
yoyo-sakura.png          - bentuk bunga pink
yoyo-sakura-trail.png    - cuplikan trail kelopak pink
yoyo-eclipse.png         - bentuk bintang ungu dan cyan
yoyo-eclipse-trail.png   - cuplikan trail bintang

PNG trail adalah gambar diam. Di dalam game, trail digambar dan
bergerak secara langsung di canvas. Semua skin bersifat kosmetik:
damage, jangkauan, dan kontrol yo-yo tidak berubah.

Sumber bentuk dan warna: src/game/yoyoSkins.ts dan src/game/yoyo.ts.
Sumber ekspor PNG: src/YoyoSkinsPanel.tsx.